"""
Agent: Devil's Advocate & Logic Error-Hunter (Hội Đồng Phản Biện Chéo & Bắt Lỗi Logic)
Vai trò: "Vạch lá tìm sâu", Red-Teaming, kiểm tra xung đột logic ngành, 
bác bỏ các quyết định cực đoan phi thực tế (False Veto), và đưa ra góc nhìn ngược dòng (Contrarian View).
"""

class DevilsAdvocateAgent:
    def __init__(self):
        self.name = "Devil's Advocate (Phản Biện Độc Lập & Bắt Lỗi Logic)"
        self.role = "Red Team & Sát Hạch Toàn Bộ Quyết Định AI Trước Khi Ban Hành"

    def review_and_counter(
        self,
        symbol: str,
        company: dict,
        tech: dict,
        financials: dict,
        sector: str,
        all_agent_scores: dict,
        burry_res: dict,
        preliminary_action: str
    ) -> dict:
        symbol = symbol.upper().strip()
        errors_found = []
        corrections_applied = []
        contrarian_points = []
        veto_overruled = False

        biz_desc = (str(company.get("business_model", "")) + " " + str(company.get("industry", "")) + " " + sector).lower()
        is_financial = any(w in biz_desc for w in ["chứng khoán", "ngân hàng", "capital markets", "financial", "banks", "banking"]) or symbol in {
            "SSI", "VND", "VCI", "HCM", "SHS", "MBS", "FTS", "BSI", "CTS", "AGR", "ORS", "VIX",
            "VCB", "TCB", "MBB", "ACB", "CTG", "BID", "VPB", "HDB", "STB", "LPB", "SHB", "VIB", "TPB", "MSB", "OCB"
        }

        # -------------------------------------------------------------
        # 1. SÁT HẠCH LỖI KHÔNG TƯƠNG THÍCH NGÀNH (SECTOR-METRIC MISMATCH AUDIT)
        # -------------------------------------------------------------
        if is_financial:
            # Sát hạch xem có ai áp dụng nhầm Z-Score hay CFO âm sản xuất cho ngành tài chính không
            burry_red_flags = burry_res.get("red_flags", [])
            for rf in burry_red_flags:
                if "Altman Z-Score" in rf:
                    errors_found.append("Lỗi áp dụng chỉ số Altman Z-Score của DN sản xuất vào Định chế Tài chính (Ngân hàng/Chứng khoán).")
                    corrections_applied.append("Vô hiệu hóa Z-Score sản xuất, chuyển sang đo lường an toàn vốn theo quy chế ngành.")
                if "Dòng tiền kinh doanh (CFO) âm" in rf and "bán hàng không thu được tiền" in rf:
                    errors_found.append("Lỗi suy diễn CFO âm là gian lận bán hàng (thực chất là giải ngân cho vay Margin/tín dụng).")
                    corrections_applied.append("Công nhận dòng tiền CFO âm là do mở rộng quy mô tín dụng/cho vay, không phạt điểm.")

            # Nếu Burry trước đó kích hoạt Veto vì các lỗi này -> BÁC BỎ VETO (OVERRULE VETO)
            if burry_res.get("veto_exercised") and any("Altman" in rf or "CFO" in rf for rf in burry_red_flags):
                veto_overruled = True
                corrections_applied.append("🚨 BÁC BỎ LỆNH PHỦ QUYẾT (OVERRULE VETO): Quyết định cấm mua của Burry bị hủy bỏ do nhầm lẫn logic kế toán ngành tài chính!")

        # -------------------------------------------------------------
        # 2. SÁT HẠCH TÍNH CỰC ĐOAN (EXTREME OUTLIER CHECK)
        # -------------------------------------------------------------
        for agent_name, sc in all_agent_scores.items():
            if sc <= 0.5:
                errors_found.append(f"Chuyên gia {agent_name} chấm điểm cực đoan ({sc}/10). Đã kiểm tra lại tính hợp lý dữ liệu.")
            elif sc >= 9.8:
                errors_found.append(f"Chuyên gia {agent_name} quá hưng phấn ({sc}/10). Đã kích hoạt bộ đệm cảnh giác rủi ro thiên nga đen.")

        # -------------------------------------------------------------
        # 3. GÓC NHÌN NGƯỢC DÒNG (CONTRARIAN COUNTER-INQUIRY)
        # -------------------------------------------------------------
        avg_score = sum(all_agent_scores.values()) / max(len(all_agent_scores), 1)
        
        if "MUA" in preliminary_action and avg_score >= 6.5:
            # Nếu tất cả đều hô Mua -> Phản biện đóng vai "Phe Gấu" (Bear Case)
            curr_p = tech.get("current_price", 0)
            ma200 = tech.get("ma200", curr_p)
            rsi = tech.get("rsi", 50)
            contrarian_points.append(
                f"🚨 CẢNH BÁO BẪY HƯNG PHẤN (BULL TRAP): RSI hiện tại là {rsi} và giá đang tiệm cận kháng cự. "
                f"Nếu thị trường chung (VN-Index) rung lắc bất ngờ, rủi ro hàng $T+2.5$ về không kịp cắt lỗ là có thật!"
            )
            contrarian_points.append(
                "Đề xuất kỷ luật: Không bao giờ mua 'Full vị thế' trong 1 phiên duy nhất. Bắt buộc chia 3 đợt mua gom!"
            )
        else:
            # Nếu đang khuyên Bán hoặc Đứng ngoài -> Phản biện tìm "Điểm sáng ngược dòng" (Contrarian Upside)
            pb = financials.get("pb", 2.0)
            if pb < 1.5:
                contrarian_points.append(
                    f"💡 CƠ HỘI ĐỊNH GIÁ RẺ: P/B đang ở mức {pb}x (vùng định giá rất rẻ trong lịch sử). "
                    f"Dù kỹ thuật đang yếu, những nhà đầu tư giá trị dài hạn (tầm nhìn 1-2 năm) có thể bắt đầu lên kế hoạch gom sàn."
                )
            else:
                contrarian_points.append(
                    "💡 GÓC NHÌN TÍCH CỰC: Dù chưa có điểm mua ngắn hạn, cổ phiếu vẫn giữ được dòng tiền và thanh khoản dồi dào, cần đưa ngay vào Watchlist để đón sóng bùng nổ khi tạo đáy xong."
                )

        # -------------------------------------------------------------
        # 4. TỔNG HỢP KẾT QUẢ SÁT HẠCH
        # -------------------------------------------------------------
        status = "PHÁT HIỆN LỖI & ĐÃ TỰ ĐỘNG HIỆU CHỈNH" if errors_found else "CHUẨN XÁC & NHẤT QUÁN 100%"
        
        return {
            "agent": self.name,
            "status": status,
            "errors_found": errors_found,
            "corrections_applied": corrections_applied,
            "veto_overruled": veto_overruled,
            "contrarian_points": contrarian_points,
            "sanity_score": 10.0 if not errors_found else max(6.0, 10.0 - len(errors_found) * 1.5)
        }
