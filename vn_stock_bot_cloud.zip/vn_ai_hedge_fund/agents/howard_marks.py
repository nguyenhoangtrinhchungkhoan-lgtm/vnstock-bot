"""
Agent: Howard Marks (Oaktree Capital / Chu kỳ Thị trường & Tư duy Cấp độ 2)
Vai trò: Bậc thầy quản trị tâm lý thị trường, con lắc Chu kỳ Tham lam - Sợ hãi & Tư duy Cấp độ 2 (Second-Level Thinking).
"""

class HowardMarksAgent:
    def __init__(self):
        self.name = "Howard Marks (Chu Kỳ & Tư Duy Cấp Độ 2)"
        self.role = "Định vị Con Lắc Tâm Lý & Đánh giá Rủi ro phi đối xứng"

    def analyze(self, company: dict, tech: dict, financials: dict) -> dict:
        symbol = company.get("symbol", "")
        pe = financials.get("pe", 15.0)
        cycle_pos = tech.get("cycle_position_pct", 50.0) # Vị trí giá trong 52 tuần (0% = Đáy, 100% = Đỉnh)
        rsi = tech.get("rsi_14", 50.0)

        # 1. ĐỊNH VỊ CON LẮC TÂM LÝ (THE PENDULUM)
        if cycle_pos >= 85.0 or rsi >= 70:
            pendulum_state = "CON LẮC Ở ĐỈNH ĐIỂM HƯNG PHẤN (EXTREME EUPHORIA)"
            risk_level = "RỦI RO CAO — Biên an toàn đã bị triệt tiêu"
            contrarian_action = "KHÔNG ĐƯỢC FOMO MUA ĐUỔI! Cân nhắc chốt lời hoặc đứng ngoài"
            marks_score = 3.5
        elif cycle_pos <= 25.0 or rsi <= 35:
            pendulum_state = "CON LẮC Ở ĐÁY BI QUAN (EXTREME PESSIMISM)"
            risk_level = "RỦI RO THẤP — Thị trường đã chiết khấu hết tin xấu"
            contrarian_action = "CƠ HỘI MUA NGƯỢC DÒNG (CONTRARIAN BARGAIN) NẾU CƠ BẢN TỐT"
            marks_score = 8.5
        else:
            pendulum_state = "CON LẮC Ở VÙNG CÂN BẰNG (NEUTRAL ZONE)"
            risk_level = "RỦI RO TRUNG BÌNH"
            contrarian_action = "THEO DÕI SỰ PHÂN HÓA GIỮA KỲ VỌNG VÀ THỰC TẾ"
            marks_score = 6.5

        # 2. TƯ DUY CẤP ĐỘ 2 (SECOND-LEVEL THINKING)
        # Cấp độ 1: "Đây là công ty tuyệt vời, hãy mua nó."
        # Cấp độ 2: "Ai cũng biết đây là công ty tuyệt vời, liệu mức giá hiện tại (P/E = ...) đã phản ánh hết điều đó chưa?"
        if pe > 24.0:
            second_level_insight = (
                f"Tư duy cấp 2 cảnh báo: Mọi nhà đầu tư trên thị trường đều đồng thuận rằng {symbol} làm ăn tốt. "
                f"Chính sự đồng thuận này đẩy P/E lên {pe}x. Bất kỳ sự chậm lại nhỏ nào trong tăng trưởng cũng sẽ dẫn tới đợt bán tháo mạnh."
            )
        elif pe < 15.0 and financials.get("profit_growth", 0) > 15:
            second_level_insight = (
                f"Tư duy cấp 2 chỉ ra: Thị trường đang đánh đồng {symbol} với các doanh nghiệp khó khăn khác và trả giá rẻ P/E = {pe}x. "
                f"Đây là cơ hội bất cân xứng (Asymmetric Opportunity): Cửa giảm có hạn nhưng cửa tăng rất rộng."
            )
        else:
            second_level_insight = (
                f"Tư duy cấp 2 nhận định: Mức giá hiện tại phản ánh tương đối cân bằng giữa triển vọng và rủi ro ngắn hạn."
            )

        thesis = (
            f"**Triết lý Chu kỳ của Howard Marks đối với {symbol}**:\n"
            f"- Vị trí con lắc tâm lý: **{pendulum_state}** (Giá đang ở mốc {cycle_pos}% biên độ 52 tuần).\n"
            f"- Đánh giá mức độ rủi ro: **{risk_level}**.\n"
            f"- **Tư duy cấp độ 2**: \"{second_level_insight}\"\n"
            f"- Lời khuyên hành động ngược dòng: **{contrarian_action}**."
        )

        return {
            "agent": self.name,
            "pendulum_state": pendulum_state,
            "cycle_position_pct": cycle_pos,
            "marks_score": marks_score,
            "second_level_insight": second_level_insight,
            "thesis": thesis
        }
