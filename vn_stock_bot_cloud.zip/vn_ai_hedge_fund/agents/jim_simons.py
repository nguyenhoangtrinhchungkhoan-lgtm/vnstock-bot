"""
Agent: Jim Simons (Renaissance Technologies / Quantitative Mathematics & Statistical Edge)
Vai trò: Nhà toán học định lượng, đo lường xác suất thống kê, độ biến động ATR và tối ưu hóa vị thế bằng mô hình định lượng.
"""

class JimSimonsAgent:
    def __init__(self):
        self.name = "Jim Simons (Toán học Định Lượng & Xác Suất)"
        self.role = "Mô hình Định lượng, Thống kê Biến động ATR & Tối ưu vị thế"

    def analyze(self, tech: dict) -> dict:
        curr_price = tech.get("current_price", 0)
        atr = tech.get("atr_14_vnd", curr_price * 0.025)
        bb_bandwidth = tech.get("bb_bandwidth_pct", 10.0)
        rsi = tech.get("rsi_14", 50.0)
        vol_ratio = tech.get("volume_ratio", 1.0)

        # Tính tỷ lệ biến động ATR %
        atr_pct = round((atr / (curr_price + 1e-9)) * 100, 2)

        # Đánh giá hiện tượng thắt nút cổ chai (Bollinger Squeeze)
        # Khi Bandwidth < 8% -> Biến động nén chặt, xác suất bùng nổ xu hướng mới rất cao
        is_squeeze = bb_bandwidth < 8.0

        # Ước tính xác suất thành công dựa trên phân phối thống kê động lượng
        # RSI trong vùng 45 - 65 kết hợp Volume bùng nổ -> Xác suất thắng cao nhất
        win_probability = 50.0 # Base 50%
        if 48 <= rsi <= 65:
            win_probability += 12.0
        elif rsi < 30: # Quá bán sâu - hồi phục kỹ thuật
            win_probability += 8.0
        elif rsi > 70: # Quá mua - rủi ro điều chỉnh
            win_probability -= 15.0

        if vol_ratio > 1.3:
            win_probability += 10.0
        elif vol_ratio < 0.6:
            win_probability -= 8.0

        win_probability = max(25.0, min(85.0, win_probability))

        # Phân loại độ biến động (Volatility Regime)
        if atr_pct > 4.0:
            vol_regime = "Biến động rất cao (High Volatility) — Rủi ro rung lắc mạnh"
            max_recommended_size = 8 # Giảm tỷ trọng khi rủi ro biến động lớn
        elif atr_pct >= 2.0:
            vol_regime = "Biến động trung bình (Normal Volatility) — Trạng thái cân bằng"
            max_recommended_size = 15
        else:
            vol_regime = "Biến động thấp / Nén chặt (Low Volatility) — Thích hợp gom hàng"
            max_recommended_size = 20

        quant_score = round((win_probability / 10.0) * 0.7 + (8.0 if is_squeeze else 5.0) * 0.3, 1)

        thesis = (
            f"**Đánh giá Định lượng của Jim Simons**:\n"
            f"- Xác suất thống kê thắng thế (Estimated Win Rate): **{win_probability:.1f}%**.\n"
            f"- Biên độ biến động ngày (ATR 14): **{atr:,.0f} VNĐ ({atr_pct}%)** $\\rightarrow$ {vol_regime}.\n"
            f"- Trạng thái Bollinger Bands: Độ mở băng **{bb_bandwidth}%** {'(ĐANG NÉN CHẶT CHUẨN BỊ BÙNG NỔ)' if is_squeeze else '(Độ mở bình thường)'}.\n"
            f"- Khuyến nghị vị thế định lượng (Volatility-adjusted size): Tối đa **{max_recommended_size}% NAV** để kiểm soát phương sai danh mục."
        )

        return {
            "agent": self.name,
            "win_probability_pct": win_probability,
            "atr_vnd": atr,
            "atr_pct": atr_pct,
            "is_squeeze": is_squeeze,
            "vol_regime": vol_regime,
            "max_quant_size_pct": max_recommended_size,
            "quant_score": quant_score,
            "thesis": thesis
        }
