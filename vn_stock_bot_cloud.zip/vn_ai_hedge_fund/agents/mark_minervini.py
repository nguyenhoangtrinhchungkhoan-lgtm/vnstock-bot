"""
Agent: Mark Minervini (Phù thủy chứng khoán / SEPA & VCP)
Vai trò: Bắt nhịp thời điểm mua (Timing), kiểm định Mẫu hình VCP, Trend Template & Thiết lập Ngưỡng cắt lỗ bảo toàn vốn.
"""

class MarkMinerviniAgent:
    def __init__(self):
        self.name = "Mark Minervini (Kỹ thuật SEPA & VCP)"
        self.role = "Bắt sóng tăng trưởng, Quản trị rủi ro & Cắt lỗ cứng"

    def analyze(self, company: dict, tech: dict) -> dict:
        symbol = company.get("symbol", "")
        curr_price = tech.get("current_price", 0)
        ma20 = tech.get("ma20", 0)
        ma50 = tech.get("ma50", 0)
        ma150 = tech.get("ma150", 0)
        ma200 = tech.get("ma200", 0)
        rsi = tech.get("rsi_14", 50.0)
        vol_ratio = tech.get("volume_ratio", 1.0)
        minervini_score = tech.get("minervini_score", "0/8")
        is_uptrend = tech.get("is_uptrend", False)
        passed_count = int(minervini_score.split("/")[0])

        # Phân loại giai đoạn cổ phiếu (4 Stages của Stan Weinstein / Minervini)
        if passed_count >= 7:
            stage = "GIAI ĐOẠN 2: UPTREND MẠNH MẼ (Tăng giá bứt phá)"
            action_recommendation = "SẴN SÀNG MUA TẠI ĐIỂM NỔ (PIVOT)"
            timing_score = 9.0
        elif passed_count >= 5:
            stage = "CHUYỂN GIAO: BẮT ĐẦU VÀO XU HƯỚNG TĂNG"
            action_recommendation = "THEO DÕI SÁT, CHỜ MẪU HÌNH THU HẸP ĐỘ BIẾN ĐỘNG VCP HOÀN THIỆN"
            timing_score = 7.0
        elif passed_count >= 3:
            stage = "GIAI ĐOẠN 1: TÍCH LŨY ĐÁY HOẶC ĐI NGANG"
            action_recommendation = "KIÊN NHẪN CHỜ ĐỢI, KHÔNG MUA VỘI ĐỂ TRÁNH CHÔN VỐN"
            timing_score = 4.5
        else:
            stage = "GIAI ĐOẠN 4: DOWNTREND / ĐANG RƠI TỰ DO"
            action_recommendation = "TUYỆT ĐỐI KHÔNG BẮT ĐAO RƠI! ĐỨNG NGOÀI QUAN SÁT"
            timing_score = 2.0

        # Thiết lập Ngưỡng cắt lỗ bảo vệ tài khoản (Tối đa 7% - 8% từ điểm mua)
        stop_loss_price = round(curr_price * 0.93, 0) # Cắt lỗ 7%
        target_price_1 = round(curr_price * 1.15, 0) # R:R = 15% / 7% > 2:1
        target_price_2 = round(curr_price * 1.25, 0) # Sóng tăng lớn

        thesis = (
            f"**Phân tích kỹ thuật & Quản trị rủi ro của Mark Minervini đối với {symbol}**:\n"
            f"- Trạng thái xu hướng: **{stage}** (Đạt {minervini_score} tiêu chuẩn Trend Template).\n"
            f"- Vị trí giá: Giá hiện tại: {curr_price:,.0f} | MA50: {ma50:,.1f} | MA200: {ma200:,.1f}.\n"
            f"- Động lượng: RSI(14) = {rsi} | Khối lượng so với TB20 phiên = {vol_ratio}x.\n"
            f"- **Quy tắc bảo vệ vốn**: Ngưỡng CẮT LỖ CỨNG bắt buộc tại **{stop_loss_price:,.0f} VNĐ (-7%)**. Nếu giá gãy mốc này, bán ngay không do dự để bảo toàn vốn cho chu kỳ sau!\n"
            f"- Khuyến nghị hành động: **{action_recommendation}**."
        )

        return {
            "agent": self.name,
            "stage": stage,
            "minervini_score": minervini_score,
            "is_uptrend": is_uptrend,
            "timing_score": timing_score,
            "action_recommendation": action_recommendation,
            "stop_loss_price": stop_loss_price,
            "target_price_1": target_price_1,
            "target_price_2": target_price_2,
            "risk_reward_ratio": "2.14 : 1 (Lãi 15% / Lỗ 7%)",
            "thesis": thesis
        }
