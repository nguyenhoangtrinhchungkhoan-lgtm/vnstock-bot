"""
Agent: Michael Burry (The Big Short / Forensic Accounting)
Vai trò: Thám tử tài chính & Kiểm soát rủi ro gian lận BCTC tại Việt Nam
Đặc quyền: QUYỀN PHỦ QUYẾT (VETO POWER) — Có quyền huỷ bỏ khuyến nghị MUA nếu phát hiện rủi ro nghiêm trọng.
"""

class MichaelBurryAgent:
    def __init__(self):
        self.name = "Michael Burry (Forensic BCTC)"
        self.role = "Giám sát gian lận & Rủi ro thanh khoản"

    def analyze(self, company: dict, financials: dict) -> dict:
        symbol = company.get("symbol", "")
        cfo_list = financials.get("cfo_history", [])
        debt_to_equity = financials.get("debt_to_equity", 0.0)
        receivables_pct = financials.get("receivables_pct_assets", 0.0)
        inventory_pct = financials.get("inventory_pct_assets", 0.0)
        altman_z = financials.get("altman_z_score", 3.0)
        audit_opinion = financials.get("audit_opinion", "Chấp nhận toàn phần")

        # Nhận diện đặc thù nhóm Định chế Tài chính (Chứng khoán, Ngân hàng)
        financial_symbols = {
            "SSI", "VND", "VCI", "HCM", "SHS", "MBS", "FTS", "BSI", "CTS", "AGR", "ORS", "VIX",
            "VCB", "TCB", "MBB", "ACB", "CTG", "BID", "VPB", "HDB", "STB", "LPB", "SHB", "VIB", "TPB", "MSB", "OCB"
        }
        biz_desc = (str(company.get("business_model", "")) + " " + str(company.get("industry", "")) + " " + str(company.get("sector", ""))).lower()
        is_financial_firm = (symbol in financial_symbols) or any(w in biz_desc for w in ["chứng khoán", "ngân hàng", "capital markets", "financial", "banking"])

        red_flags = []
        warnings = []

        # 1. Kiểm tra dòng tiền kinh doanh (CFO)
        if any(c < 0 for c in cfo_list):
            if is_financial_firm:
                # Với CTCK/Ngân hàng: CFO âm là do tăng giải ngân cho vay Margin hoặc tiền gửi, không phải lợi nhuận ảo
                warnings.append("Dòng tiền CFO âm do mở rộng cho vay Margin/nguồn vốn (Chuẩn mực TT 334/2016/TT-BTC, không phải rủi ro bán hàng ảo).")
            else:
                neg_count = sum(1 for c in cfo_list if c < 0)
                if neg_count >= 2:
                    red_flags.append(f"Dòng tiền kinh doanh (CFO) âm {neg_count} năm trong 3 năm gần nhất. Nguy cơ lợi nhuận ảo, bán hàng không thu được tiền!")
                else:
                    warnings.append("Có 1 năm CFO âm trong quá khứ, cần theo dõi chu kỳ hồi phục tiền mặt.")

        # 2. Kiểm tra ý kiến kiểm toán
        if "ngoại trừ" in audit_opinion.lower() or "từ chối" in audit_opinion.lower():
            red_flags.append(f"Ý kiến kiểm toán bất thường: '{audit_opinion}'. Rủi ro số liệu bị che giấu!")

        # 3. Kiểm tra khoản phải thu / Tổng tài sản
        receivable_limit = 50.0 if is_financial_firm else 35.0
        if receivables_pct > receivable_limit:
            red_flags.append(f"Khoản phải thu chiếm {receivables_pct}% tổng tài sản (>{receivable_limit}%). Dấu hiệu chiếm dụng vốn hoặc doanh thu ảo qua sân sau!")
        elif receivables_pct > (receivable_limit - 10.0):
            warnings.append(f"Khoản phải thu ở mức khá cao ({receivables_pct}% tổng tài sản).")

        # 4. Kiểm tra nợ vay / Vốn chủ sở hữu (Đòn bẩy)
        # CTCK theo luật được nợ/VCSH tối đa 5x; DN sản xuất chuẩn là 2x
        debt_limit = 4.5 if is_financial_firm else 2.0
        if debt_to_equity > debt_limit:
            red_flags.append(f"Đòn bẩy tài chính quá cao: Nợ/VCSH = {debt_to_equity}x (> {debt_limit}x). Rủi ro kiệt quệ tài chính khi lãi suất biến động!")
        elif debt_to_equity > (debt_limit * 0.7):
            warnings.append(f"Nợ vay/VCSH = {debt_to_equity}x, cần chú ý chi phí lãi vay hàng quý.")

        # 5. Kiểm tra Altman Z-Score
        if is_financial_firm:
            # Giáo sư Edward Altman khẳng định Z-Score KHÔNG áp dụng cho Ngân hàng và CTCK
            warnings.append("Chỉ số Altman Z-Score không áp dụng cho định chế tài chính (theo nguyên lý của GS Altman).")
        else:
            if altman_z < 1.81:
                red_flags.append(f"Chỉ số Altman Z-Score = {altman_z} (< 1.81 - Vùng báo động đỏ nguy cơ mất khả năng thanh toán/phá sản).")
            elif altman_z < 2.99:
                warnings.append(f"Altman Z-Score = {altman_z} (Vùng xám 1.81 - 2.99, cần thận trọng).")

        # Quyết định Phủ quyết (Veto)
        veto_exercised = len(red_flags) >= 1
        safety_status = "BÁO ĐỘNG ĐỎ - PHỦ QUYẾT" if veto_exercised else ("CẢNH BÁO - CẦN GIÁM SÁT" if warnings else "AN TOÀN TUYỆT ĐỐI")

        assessment = (
            f"Báo cáo tài chính của {symbol} ({'Nhóm Định Chế Tài Chính' if is_financial_firm else 'Doanh Nghiệp Sản Xuất/Thương Mại'}) có mức độ rủi ro: **{safety_status}**.\n"
            f"- Đòn bẩy nợ/VCSH: {debt_to_equity}x | Khoản phải thu: {receivables_pct}% tài sản.\n"
            f"- Dòng tiền CFO: {cfo_list} tỷ VNĐ.\n"
            f"- Altman Z-Score: {'N/A (Định chế tài chính)' if is_financial_firm else altman_z} | Kiểm toán: {audit_opinion}."
        )

        return {
            "agent": self.name,
            "safety_status": safety_status,
            "veto_exercised": veto_exercised,
            "red_flags": red_flags,
            "warnings": warnings,
            "altman_z_score": altman_z,
            "cfo_trend": "Lành mạnh" if not red_flags else "Nguy hiểm",
            "assessment": assessment
        }
