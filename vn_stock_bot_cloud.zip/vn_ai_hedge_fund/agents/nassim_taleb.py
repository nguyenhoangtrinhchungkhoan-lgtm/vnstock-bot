"""
Agent: Nassim Nicholas Taleb (Thiên Nga Đen & Khả Năng Chống Đổ Vỡ - Antifragility)
Vai trò: Chuyên gia kiểm định rủi ro đuôi (Tail Risk), rủi ro kẹp thanh khoản (Liquidity Trap) & khả năng sống sót qua khủng hoảng.
"""

class NassimTalebAgent:
    def __init__(self):
        self.name = "Nassim Taleb (Thiên Nga Đen & Antifragile)"
        self.role = "Kiểm định Rủi ro Đuôi, Bẫy Thanh Khoản & Sống Sót Qua Khủng Hoảng"

    def analyze(self, company: dict, tech: dict, financials: dict) -> dict:
        symbol = company.get("symbol", "")
        debt_to_equity = financials.get("debt_to_equity", 0.5)
        cash_reserves = financials.get("cash_and_equivalents", 0) # Tỷ VNĐ
        turnover_billion = tech.get("avg_daily_turnover_billion", 50.0) # Thanh khoản bình quân ngày (Tỷ VNĐ)

        fragility_flags = []

        # 1. KIỂM ĐỊNH BẪY THANH KHOẢN (LIQUIDITY TRAP RISK) - ĐẶC SẢN VIỆT NAM
        # Tại VN, khi thị trường sập sàn liên tục, các mã thanh khoản thấp sẽ "trắng bên mua"
        if turnover_billion < 5.0:
            fragility_flags.append(f"Thanh khoản quá thấp ({turnover_billion} tỷ/phiên). NGUY CƠ MẤT THANH KHOẢN, kẹp sàn không thoát được hàng khi có biến cố!")
            liquidity_status = "BẪY THANH KHOẢN NGUY HIỂM"
        elif turnover_billion < 20.0:
            liquidity_status = "THANH KHOẢN TRUNG BÌNH (Cần kiểm soát quy mô lệnh)"
        else:
            liquidity_status = f"THANH KHOẢN DỒI DÀO ({turnover_billion:,.1f} tỷ/phiên — Dễ dàng cắt lỗ bảo toàn vốn)"

        # 2. ĐÁNH GIÁ TÍNH CHỐNG ĐỔ VỠ (ANTIFRAGILITY)
        # Fragile (Dễ vỡ): Nợ vay lớn, tiền mặt cạn kiệt
        # Robust (Bền bỉ): Nợ vừa phải, tiền mặt đủ duy trì
        # Antifragile (Chống đổ vỡ): Tiền mặt dồi dào, không nợ, hưởng lợi khi đối thủ phá sản
        if debt_to_equity > 1.5:
            fragility_flags.append(f"Đòn bẩy nợ cao ({debt_to_equity}x), rất dễ gãy đổ khi có sự kiện Thiên Nga Đen (lãi suất tăng đột ngột, siết tín dụng).")
            antifragile_status = "DỄ VỠ (FRAGILE) — Rủi ro sụp đổ dây chuyền"
            taleb_score = 3.0
        elif cash_reserves > 10_000 and debt_to_equity < 0.6:
            antifragile_status = "CHỐNG ĐỔ VỠ (ANTIFRAGILE) — Lượng tiền mặt lớn ({cash_reserves:,.0f} tỷ) giúp hưởng lợi thâu tóm đối thủ khi khủng hoảng"
            taleb_score = 9.0
        else:
            antifragile_status = "BỀN BỈ (ROBUST) — Đủ sức vượt qua bão giông thông thường"
            taleb_score = 7.0

        # 3. STRESS-TEST KỊCH BẢN THIÊN NGA ĐEN (BLACK SWAN SIMULATION)
        # Giả định VN-Index giảm sốc 80 điểm trong 2 phiên liên tiếp
        stress_test_passed = len(fragility_flags) == 0 and turnover_billion >= 20.0

        thesis = (
            f"**Thẩm định Rủi ro Cực Đoan của Nassim Taleb đối với {symbol}**:\n"
            f"- Cấp độ an toàn cấu trúc: **{antifragile_status}**.\n"
            f"- Kiểm tra rủi ro kẹt sàn: **{liquidity_status}**.\n"
            f"- Lớp đệm tiền mặt: Doanh nghiệp dự trữ **{cash_reserves:,.0f} tỷ VNĐ** tiền và tương đương tiền.\n"
            f"- Kết quả Stress-test sự kiện Thiên Nga Đen: **{'✅ ĐẠT CHUẨN SỐNG SÓT' if stress_test_passed else '⚠️ CẢNH BÁO RỦI RO ĐUÔI'}**."
        )

        return {
            "agent": self.name,
            "liquidity_status": liquidity_status,
            "antifragile_status": antifragile_status,
            "taleb_score": taleb_score,
            "stress_test_passed": stress_test_passed,
            "fragility_flags": fragility_flags,
            "thesis": thesis
        }
