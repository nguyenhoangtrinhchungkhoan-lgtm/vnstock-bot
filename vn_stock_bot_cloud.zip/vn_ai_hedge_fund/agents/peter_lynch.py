"""
Agent: Peter Lynch (GARP - Growth at a Reasonable Price)
Vai trò: Săn tìm cổ phiếu tăng trưởng từ thực tế đời sống & tối ưu hóa chỉ số PEG
"""

class PeterLynchAgent:
    def __init__(self):
        self.name = "Peter Lynch (GARP & Tăng trưởng)"
        self.role = "Săn tìm cổ phiếu tăng trưởng giá hợp lý & Chỉ số PEG"

    def analyze(self, company: dict, financials: dict, tech: dict) -> dict:
        symbol = company.get("symbol", "")
        pe = financials.get("pe", 15.0)
        profit_growth = financials.get("profit_growth", 15.0) # %
        rev_growth = financials.get("revenue_growth", 12.0)
        peg = financials.get("peg_ratio", round(pe / (profit_growth + 1e-9), 2))

        # Phân loại danh mục theo Peter Lynch
        if profit_growth >= 20.0:
            category = "Công ty tăng trưởng nhanh (Fast Grower)"
        elif profit_growth >= 10.0:
            category = "Công ty phát triển vững chắc (Stalwart)"
        elif "thép" in company.get("business_model", "").lower() or "dầu khí" in company.get("business_model", "").lower():
            category = "Cổ phiếu chu kỳ (Cyclical)"
        else:
            category = "Công ty tăng trưởng chậm / Tiêu dùng ổn định (Slow Grower)"

        # Đánh giá chỉ số PEG
        # PEG < 1.0: Rất hấp dẫn
        # 1.0 <= PEG <= 1.5: Hợp lý
        # PEG > 1.5: Đắt đỏ
        if peg < 0.8:
            peg_status = "SIÊU HẤP DẪN (PEG < 0.8: Tăng trưởng vượt xa mức giá đang trả)"
            lynch_points = 9.5
        elif peg <= 1.2:
            peg_status = "HẤP DẪN / HỢP LÝ (PEG ~ 1.0: Tăng trưởng tương xứng định giá)"
            lynch_points = 8.0
        elif peg <= 1.6:
            peg_status = "ĐỊNH GIÁ CAO (PEG 1.2 - 1.6: Cần tăng trưởng bứt phá hơn để bù đắp)"
            lynch_points = 6.0
        else:
            peg_status = "QUÁ ĐẮT (PEG > 1.6: Thị trường đang trả giá quá cao cho sự kỳ vọng)"
            lynch_points = 4.0

        thesis = (
            f"**Nhận định của Peter Lynch đối với {symbol}**:\n"
            f"- Phân loại Lynch: **{category}**.\n"
            f"- Tốc độ tăng trưởng: Lợi nhuận +{profit_growth}%/năm | Doanh thu +{rev_growth}%/năm.\n"
            f"- Chỉ số PEG: **{peg}x** (P/E = {pe}x / Tăng trưởng = {profit_growth}%) $\\rightarrow$ {peg_status}.\n"
            f"- Điểm số Lynch: **{lynch_points}/10**."
        )

        return {
            "agent": self.name,
            "category": category,
            "peg_ratio": peg,
            "peg_status": peg_status,
            "lynch_score": lynch_points,
            "growth_rate": profit_growth,
            "thesis": thesis
        }
