"""
Agent: Portfolio Manager (Trưởng Ban Đầu Tư / Chief Investment Officer)
Vai trò: Chủ trì cuộc họp hội đồng 10 Siêu AI, kiểm tra quyền phủ quyết, tổng hợp ma trận trọng số và ra khuyến nghị quản trị rủi ro hoàn hảo.
"""

class PortfolioManagerAgent:
    def __init__(self):
        self.name = "Portfolio Manager (Trưởng Ban Đầu Tư)"
        self.role = "Tổng hợp tranh biện 10 Siêu AI, Chấm điểm Ma trận & Ra quyết định thực chiến"

    def arbitrate_comprehensive(self, 
                                company: dict,
                                tech: dict,
                                burry_res: dict, 
                                buffett_res: dict, 
                                lynch_res: dict, 
                                minervini_res: dict, 
                                druckenmiller_res: dict,
                                simons_res: dict,
                                marks_res: dict,
                                taleb_res: dict,
                                wyckoff_res: dict,
                                auditor_res: dict) -> dict:
        
        symbol = company.get("symbol", "")
        company_name = company.get("company_name", symbol)
        curr_price = tech.get("current_price", 0)

        # 1. KIỂM TRA CÁC CHỐT CHẶN PHỦ QUYẾT (VETO & LIQUIDITY TRAP)
        if burry_res.get("veto_exercised", False):
            return self._build_rejection_decision(
                symbol, company_name,
                "❌ TỪ CHỐI ĐẦU TƯ (PHỦ QUYẾT DO GIAN LẬN BCTC)",
                f"Lệnh Mua bị hủy bởi Michael Burry do phát hiện rủi ro nghiêm trọng: {'; '.join(burry_res.get('red_flags', []))}."
            )

        if "bẫy thanh khoản" in taleb_res.get("liquidity_status", "").lower():
            return self._build_rejection_decision(
                symbol, company_name,
                "❌ TỪ CHỐI ĐẦU TƯ (RỦI RO BẪY THANH KHOẢN KẸP SÀN)",
                f"Nassim Taleb cảnh báo: Cổ phiếu có thanh khoản quá thấp, nguy cơ mất thanh khoản trắng bên mua khi thị trường rung lắc!"
            )

        # 2. TÍNH ĐIỂM MA TRẬN 10 CHIỀU CÓ TRỌNG SỐ (COMPOSITE WEIGHTED SCORE)
        # Nhóm Cơ bản (27%): Buffett (15%) + Lynch (12%)
        # Nhóm Kỹ thuật & Cá mập (30%): Minervini (18%) + Wyckoff (12%)
        # Nhóm Định lượng & An toàn (23%): Simons (12%) + Taleb (11%)
        # Nhóm Vĩ mô & Chu kỳ (20%): Druckenmiller (10%) + Howard Marks (10%)
        w_buffett = buffett_res.get("buffett_score", 5.0) * 0.15
        w_lynch = lynch_res.get("lynch_score", 5.0) * 0.12
        w_minervini = minervini_res.get("timing_score", 5.0) * 0.18
        w_wyckoff = wyckoff_res.get("whale_score", 5.0) * 0.12
        w_simons = simons_res.get("quant_score", 5.0) * 0.12
        w_taleb = taleb_res.get("taleb_score", 5.0) * 0.11
        w_druckenmiller = druckenmiller_res.get("macro_score", 5.0) * 0.10
        w_marks = marks_res.get("marks_score", 5.0) * 0.10

        composite_score = round(w_buffett + w_lynch + w_minervini + w_wyckoff + 
                                w_simons + w_taleb + w_druckenmiller + w_marks, 2)

        # 3. ĐIỀU CHỈNH TỶ TRỌNG VỊ THẾ BẰNG ĐỊNH LƯỢNG & BỘ ĐỆM KẸT SÀN T+2.5
        base_quant_size = simons_res.get("max_quant_size_pct", 15)
        # Nếu Quant Auditor cảnh báo độ phân hóa cao -> Giảm 40% tỷ trọng
        if "HIGH DIVERGENCE" in auditor_res.get("consensus_status", ""):
            base_quant_size = int(base_quant_size * 0.6)

        # Kiểm tra Bộ đệm Rủi ro Kẹt Sàn T+2.5
        fli_risk = tech.get("floor_lock_risk", "THẤP (An toàn thanh khoản)")
        floor_days = tech.get("floor_days_in_60d", 0)
        staged_entry_note = ""

        if "RẤT CAO" in fli_risk:
            base_quant_size = min(base_quant_size, 5) # Tối đa 5% NAV nếu rủi ro kẹt sàn cao
            staged_entry_note = "⚠️ RỦI RO KẸT SÀN T+2.5 RẤT CAO: Đã từng có các phiên sàn trong 60 ngày. Chỉ được giải ngân tối đa 5% NAV!"
        elif "TRUNG BÌNH" in fli_risk:
            base_quant_size = min(base_quant_size, 10) # Tối đa 10% NAV
            staged_entry_note = "📌 BẢO VỆ T+2.5: Bắt buộc chia làm 3 đợt giải ngân (30% - 30% - 40%), chỉ mua gia tăng khi hàng đợt 1 đã về tài khoản và có lãi!"

        is_uptrend = minervini_res.get("is_uptrend", False)
        passed_minervini = int(minervini_res.get("minervini_score", "0/8").split("/")[0])

        # 4. TÍNH TOÁN KẾ HOẠCH TÁC CHIẾN VỐN & VÙNG GIÁ MUA CHUYÊN NGHIỆP
        trade_plan = self._calculate_actionable_trade_plan(
            curr_price=curr_price,
            tech=tech,
            minervini_res=minervini_res,
            composite_score=composite_score,
            is_veto=False
        )

        # 5. PHÁN QUYẾT ĐẦU TƯ
        if composite_score >= 7.8 and is_uptrend:
            final_action = "🟢 MUA / GIẢI NGÂN TÍCH LŨY (BUY & ACCUMULATE)"
            position_size = min(base_quant_size, 18)
        elif composite_score >= 6.5:
            if passed_minervini < 4:
                final_action = "🟡 THEO DÕI SÁT (WATCHLIST) — CHƯA VÀO LỆNH"
                position_size = 0
            else:
                final_action = "🟢 MUA THĂM DÒ TỶ TRỌNG NHỎ (TEST 5-8% NAV)"
                position_size = min(base_quant_size, 8)
        else:
            final_action = "🔴 ĐỨNG NGOÀI QUAN SÁT (PASS) / KHÔNG GIẢI NGÂN"
            position_size = 0

        executive_summary = (
            f"**Hội đồng 10 Siêu AI thông qua quyết định**: **{final_action}** đối với cổ phiếu **{symbol} ({company_name})**.\n"
            f"- Điểm số tổng hợp đa chiều: **{composite_score}/10**.\n"
            f"- Tỷ trọng phân bổ khuyến nghị: **{position_size}% NAV** (Đã áp dụng Bộ đệm biến động ATR và rủi ro T+2.5).\n"
            f"- Trạng thái rủi ro kẹt sàn T+2.5: **{fli_risk}** (Số phiên sàn 60 ngày: {floor_days}).\n"
            f"- Trạng thái đồng thuận hội đồng: **{auditor_res.get('consensus_status')}**.\n"
            f"- Vùng mua gom chiết khấu: **{trade_plan['buy_zone']}**\n"
            f"- Điểm bùng nổ vượt cản: **{trade_plan['breakout_point']}**\n"
            f"- Cắt lỗ bảo toàn vốn: **{trade_plan['stop_loss']}** | Mục tiêu: **{trade_plan['target_price']}**.\n"
            f"- Tỷ lệ Lời / Lỗ (R:R): **{trade_plan['risk_reward']}**.\n"
            f"- Căn cứ PTKT Cắt lỗ: {trade_plan.get('stop_loss_ta_reason')}\n"
            f"- Căn cứ PTKT Chốt lời: {trade_plan.get('target_ta_reason')}\n"
            f"{staged_entry_note}"
        )

        return {
            "final_action": final_action,
            "composite_score": composite_score,
            "position_size_pct": position_size,
            "buy_zone": trade_plan["buy_zone"],
            "buy_ta_reason": trade_plan.get("buy_ta_reason", ""),
            "breakout_point": trade_plan["breakout_point"],
            "stop_loss": trade_plan["stop_loss"],
            "stop_loss_ta_reason": trade_plan.get("stop_loss_ta_reason", ""),
            "target_price": trade_plan["target_price"],
            "target_ta_reason": trade_plan.get("target_ta_reason", ""),
            "trailing_stop_rule": trade_plan.get("trailing_stop_rule", ""),
            "risk_reward": trade_plan["risk_reward"],
            "entry_tactic": trade_plan["entry_tactic"],
            "sl_price_num": trade_plan.get("sl_price_num", 0),
            "tp1_price_num": trade_plan.get("tp1_price_num", 0),
            "tp2_price_num": trade_plan.get("tp2_price_num", 0),
            "fli_risk": fli_risk,
            "staged_entry_note": staged_entry_note,
            "executive_summary": executive_summary
        }

    def _calculate_actionable_trade_plan(self, curr_price: float, tech: dict, minervini_res: dict, composite_score: float, is_veto: bool = False):
        if is_veto or curr_price <= 0:
            return {
                "buy_zone": "Tuyệt đối không mua (Cảnh báo gian lận BCTC)",
                "buy_ta_reason": "Doanh nghiệp bị Michael Burry kích hoạt VETO gian lận sổ sách, chỉ số Altman-Z báo động đỏ.",
                "breakout_point": "Không áp dụng",
                "stop_loss": "Không áp dụng",
                "stop_loss_ta_reason": "Không giải ngân thì không có rủi ro cắt lỗ.",
                "target_price": "Không áp dụng",
                "target_ta_reason": "Cổ phiếu không đạt chuẩn đầu tư.",
                "trailing_stop_rule": "Không áp dụng",
                "risk_reward": "Không áp dụng",
                "entry_tactic": "Đứng ngoài hoàn toàn để bảo vệ tiền mồ hôi nước mắt!",
                "sl_price_num": 0,
                "tp1_price_num": 0,
                "tp2_price_num": 0
            }

        ma20 = tech.get("ma20", curr_price)
        ma50 = tech.get("ma50", curr_price)
        ma200 = tech.get("ma200", curr_price)
        bb_lower = tech.get("bb_lower", curr_price * 0.95)
        bb_upper = tech.get("bb_upper", curr_price * 1.05)
        low_52w = tech.get("52w_low", curr_price * 0.85)
        high_52w = tech.get("52w_high", curr_price * 1.25)
        swing_low_20 = tech.get("swing_low_20", bb_lower)
        swing_high_20 = tech.get("swing_high_20", bb_upper)
        support_s1 = tech.get("support_s1", bb_lower)
        resistance_r1 = tech.get("resistance_r1", bb_upper)
        atr = tech.get("atr_14_vnd", curr_price * 0.025)
        vol20 = tech.get("volume_20avg", 2_000_000)
        is_uptrend = tech.get("is_uptrend", False)
        rsi = tech.get("rsi_14", 50.0)

        # KỊCH BẢN 1: CỔ PHIẾU ĐANG TRONG UPTREND (GIAI ĐOẠN 2 - TREND TEMPLATE ĐẠT CHUẨN)
        if is_uptrend and composite_score >= 7.0:
            support_level = max(ma20, swing_low_20)
            buy_low = round(max(support_level * 0.985, curr_price * 0.96), 0)
            buy_high = round(min(support_level * 1.015, curr_price * 1.005), 0)
            if buy_low >= buy_high:
                buy_low = round(curr_price * 0.97, 0)
                buy_high = round(curr_price * 1.005, 0)

            ref_buy = (buy_low + buy_high) / 2

            # Cắt lỗ kỹ thuật: Dưới đáy Swing Low 20 phiên hoặc MA20, khống chế tối đa -7% Minervini
            sl_price = round(max(ref_buy * 0.93, min(ref_buy * 0.94, swing_low_20 * 0.985)), 0)
            sl_price = min(sl_price, round(ref_buy * 0.93, 0))
            sl_pct = round(((ref_buy - sl_price) / ref_buy) * 100, 1)

            # Chốt lời kỹ thuật TP1: Kháng cự R1 / Dải trên Bollinger Band
            tp1_price = round(max(ref_buy * 1.12, min(resistance_r1, bb_upper, swing_high_20)), 0)
            if tp1_price <= ref_buy * 1.08:
                tp1_price = round(ref_buy * 1.15, 0)
            tp1_pct = round(((tp1_price - ref_buy) / ref_buy) * 100, 1)

            # Chốt lời kỹ thuật TP2: Đỉnh 52 tuần hoặc Fibonacci Extension 161.8%
            fibo_161 = round(ref_buy + 1.618 * (tp1_price - ref_buy), 0)
            tp2_price = round(max(high_52w, fibo_161, ref_buy * 1.25), 0)
            tp2_pct = round(((tp2_price - ref_buy) / ref_buy) * 100, 1)

            rr_ratio = round((tp1_price - ref_buy) / max(ref_buy - sl_price, 1), 1)

            buy_zone = f"{buy_low:,.0f} - {buy_high:,.0f} VNĐ"
            buy_ta_reason = f"Kéo ngược kiểm định hỗ trợ động MA20 ({ma20:,.0f} đ) & đáy hộp Swing Low ({swing_low_20:,.0f} đ), RSI ({rsi}) duy trì trên 50."

            pivot_level = round(max(high_52w * 0.98, curr_price * 1.025), 0)
            vol_trigger = round((vol20 * 1.4) / 1_000_000, 1)
            breakout_point = f"Vượt {pivot_level:,.0f} VNĐ kèm Khối lượng > {vol_trigger}M cp"

            stop_loss = f"{sl_price:,.0f} VNĐ (-{sl_pct}%)"
            stop_loss_ta_reason = f"Thủng đáy hộp kỹ thuật Swing Low ({swing_low_20:,.0f} đ) hoặc gãy MA20 ({ma20:,.0f} đ), vi phạm giới hạn cắt lỗ cứng -{sl_pct}% Minervini."

            target_price = f"TP1: {tp1_price:,.0f} VNĐ (+{tp1_pct}%) | TP2: {tp2_price:,.0f} VNĐ (+{tp2_pct}%)"
            target_ta_reason = f"TP1 tại dải trên Bollinger Band ({bb_upper:,.0f} đ) / Kháng cự R1 (Chốt 50%); TP2 tại đỉnh 52 tuần ({high_52w:,.0f} đ) hoặc Fibonacci 161.8%."
            trailing_stop_rule = f"Nâng dần điểm chặn lãi (Trailing Stop) theo MA20 ({ma20:,.0f} VNĐ) để gồng trọn con sóng lớn."
            risk_reward = f"1 : {rr_ratio} (Chịu rủi ro -{sl_pct}% để kỳ vọng lãi +{tp1_pct}% đến +{tp2_pct}%)"
            entry_tactic = "Chia 3 đợt (30% - 30% - 40%). Mua đợt 1 tại vùng gom, gia tăng khi vượt Pivot kèm Vol lớn!"

        # KỊCH BẢN 2: CỔ PHIẾU TÍCH LŨY HOẶC ĐIỀU CHỈNH TRUNG HẠN (CHỜ VÀO SÓNG)
        elif composite_score >= 5.5:
            support_bottom = max(support_s1, bb_lower, swing_low_20)
            buy_low = round(support_bottom, 0)
            buy_high = round(min(curr_price * 0.99, support_bottom + 1.2 * atr), 0)
            if buy_low >= buy_high:
                buy_low = round(curr_price * 0.94, 0)
                buy_high = round(curr_price * 0.98, 0)

            ref_buy = (buy_low + buy_high) / 2
            discount_pct = round(((curr_price - ref_buy) / curr_price) * 100, 1)

            sl_price = round(min(ref_buy * 0.93, swing_low_20 * 0.98), 0)
            sl_price = min(sl_price, round(ref_buy * 0.93, 0))
            sl_pct = round(((ref_buy - sl_price) / ref_buy) * 100, 1)

            c_target = ma50 if curr_price < ma50 else (curr_price * 1.12)
            tp1_price = round(max(ref_buy * 1.10, c_target), 0)
            tp1_pct = round(((tp1_price - ref_buy) / ref_buy) * 100, 1)

            tp2_price = round(max(ma200 * 1.05, ref_buy * 1.25), 0)
            tp2_pct = round(((tp2_price - ref_buy) / ref_buy) * 100, 1)

            rr_ratio = round((tp1_price - ref_buy) / max(ref_buy - sl_price, 1), 1)

            buy_zone = f"{buy_low:,.0f} - {buy_high:,.0f} VNĐ"
            buy_ta_reason = f"Vùng đáy hỗ trợ kỹ thuật Swing Low ({swing_low_20:,.0f} đ) & dải dưới Bollinger Band ({bb_lower:,.0f} đ), chiết khấu ~{discount_pct}%."

            if curr_price < ma50:
                vol_trigger = round((vol20 * 1.5) / 1_000_000, 1)
                breakout_point = f"Chờ bứt phá vượt cản MA50 ({ma50:,.0f} VNĐ) kèm Vol > {vol_trigger}M cp"
            else:
                vol_trigger = round((vol20 * 1.3) / 1_000_000, 1)
                breakout_point = f"Vượt cản ngắn hạn {round(curr_price * 1.03, 0):,.0f} VNĐ kèm Vol > {vol_trigger}M cp"

            stop_loss = f"{sl_price:,.0f} VNĐ (-{sl_pct}%)"
            stop_loss_ta_reason = f"Thủng đáy hỗ trợ kỹ thuật ({support_bottom:,.0f} đ) hoặc gãy nền đáy 20 phiên, kích hoạt cắt lỗ cứng -{sl_pct}%."

            target_price = f"TP1: {tp1_price:,.0f} VNĐ (+{tp1_pct}%) | TP2: {tp2_price:,.0f} VNĐ (+{tp2_pct}%)"
            target_ta_reason = f"TP1 tại cản MA50 ({ma50:,.0f} đ); TP2 tại cản dài hạn MA200 ({ma200:,.0f} đ) hoặc nhịp hồi kỹ thuật Fibo."
            trailing_stop_rule = f"Khi giá vượt MA20 ({ma20:,.0f} đ), dời điểm cắt lỗ về giá hòa vốn để triệt tiêu rủi ro."
            risk_reward = f"1 : {rr_ratio} (Rủi ro -{sl_pct}% / Kỳ vọng lãi +{tp1_pct}% đến +{tp2_pct}%)"
            entry_tactic = "Kiên nhẫn chờ giá về sát vùng gom chiết khấu hoặc đợi bùng nổ vượt MA50 mới giải ngân!"

        # KỊCH BẢN 3: DOWNTREND / NGUY HIỂM / KHÔNG NÊN MUA
        else:
            buy_zone = "CHƯA NÊN MUA (Giá nằm dưới MA20/MA50, xu hướng giảm)"
            buy_ta_reason = f"Đường giá ({curr_price:,.0f} đ) đang dưới MA20 ({ma20:,.0f} đ) và MA50 ({ma50:,.0f} đ), chưa hình thành đáy cân bằng."
            breakout_point = f"Cần ít nhất 4-6 tuần tích lũy ngừng rơi vượt lại MA50 ({ma50:,.0f} VNĐ)"
            sl_price = round(curr_price * 0.93, 0)
            stop_loss = f"{sl_price:,.0f} VNĐ (-7%)"
            stop_loss_ta_reason = "Nếu đang có hàng, thủng mốc này bắt buộc cắt dứt khoát tránh kẹt vốn nặng."
            target_price = "Không áp dụng cho cổ phiếu đang gãy sóng"
            target_ta_reason = "Ưu tiên giữ tiền mặt, không đặt cược trong downtrend."
            trailing_stop_rule = "Không áp dụng"
            risk_reward = "Kém (Tỷ lệ rủi ro thua lỗ cao hơn lợi nhuận)"
            entry_tactic = "Đứng ngoài quan sát, tuyệt đối KHÔNG BẮT DAO RƠI!"
            sl_price = round(curr_price * 0.93, 0)
            tp1_price = 0
            tp2_price = 0

        return {
            "buy_zone": buy_zone,
            "buy_ta_reason": buy_ta_reason,
            "breakout_point": breakout_point,
            "stop_loss": stop_loss,
            "stop_loss_ta_reason": stop_loss_ta_reason,
            "target_price": target_price,
            "target_ta_reason": target_ta_reason,
            "trailing_stop_rule": trailing_stop_rule,
            "risk_reward": risk_reward,
            "entry_tactic": entry_tactic,
            "sl_price_num": sl_price,
            "tp1_price_num": tp1_price,
            "tp2_price_num": tp2_price
        }

    def _build_rejection_decision(self, symbol: str, company_name: str, action: str, reason: str) -> dict:
        return {
            "final_action": action,
            "composite_score": 0.0,
            "position_size_pct": 0,
            "buy_zone": "Tuyệt đối không mua (Cảnh báo gian lận BCTC)",
            "breakout_point": "Không áp dụng",
            "stop_loss": "Không áp dụng",
            "target_price": "Không áp dụng",
            "risk_reward": "Không áp dụng",
            "entry_tactic": "Đứng ngoài hoàn toàn để bảo vệ tiền mồ hôi nước mắt!",
            "executive_summary": f"**Hội đồng quyết định**: {action} đối với {symbol} ({company_name}). Lý do: {reason}"
        }
