"""
Agent: Senior Quant & Model Auditor (Thẩm Định Viên Thuật Toán & Rủi Ro Mô Hình)
Vai trò: Giám sát toàn bộ hệ thống bot, kiểm định tính toàn vẹn của dữ liệu, đo lường độ phân hóa (Divergence) giữa các AI và ngăn chặn thiên lệch nhận thức.
"""

class QuantAuditorAgent:
    def __init__(self):
        self.name = "Senior Quant Auditor (Kiểm Định Thuật Toán)"
        self.role = "Giám sát Chất Lượng Dữ Liệu & Đo Độ Phân Hóa Đồng Thuận (Consensus)"

    def audit_system(self, all_agent_scores: dict, tech: dict, financials: dict) -> dict:
        scores = list(all_agent_scores.values())
        avg_score = sum(scores) / len(scores)
        
        # 1. TÍNH ĐỘ LỆCH CHUẨN (STANDARD DEVIATION) CỦA CÁC ĐIỂM SỐ AI
        # Đo mức độ bất đồng quan điểm giữa các trường phái
        variance = sum((x - avg_score) ** 2 for x in scores) / len(scores)
        std_dev = variance ** 0.5

        if std_dev >= 2.5:
            consensus_status = "BẤT ĐỒNG QUAN ĐIỂM GAY GẮT (HIGH DIVERGENCE)"
            audit_warning = (
                f"Độ lệch điểm số giữa các AI là {std_dev:.2f} (>2.5). "
                f"Có sự mâu thuẫn lớn giữa các trường phái (VD: Cơ bản đánh giá rất cao nhưng Kỹ thuật/Cá mập cảnh báo nguy hiểm). "
                f"Khuyến nghị Portfolio Manager: BẮT BUỘC HẠ TỶ TRỌNG GIẢI NGÂN XUỐNG DƯỚI 10% NAV để phòng ngừa sai số!"
            )
        elif std_dev >= 1.5:
            consensus_status = "ĐỒNG THUẬN TƯƠNG ĐỐI (MODERATE CONSENSUS)"
            audit_warning = f"Độ phân hóa điểm số ở mức kiểm soát được ({std_dev:.2f})."
        else:
            consensus_status = "ĐỒNG THUẬN CAO (STRONG CONSENSUS)"
            audit_warning = f"Các AI có mức độ nhất quán cao ({std_dev:.2f}). Tín hiệu đầu tư có độ tin cậy thống kê lớn."

        # 2. KIỂM ĐỊNH TÍNH TOÀN VẸN CỦA DỮ LIỆU (DATA INTEGRITY AUDIT)
        data_checks = []
        if tech.get("volume_latest", 0) > 0:
            data_checks.append("Dữ liệu nến giá và khối lượng khớp lệnh từ Sở HOSE/HNX hợp lệ.")
        if financials.get("pe", 0) > 0:
            data_checks.append("Chỉ số định giá tài chính P/E, P/B và ROE được xác thực.")
        if tech.get("atr_14_vnd", 0) > 0:
            data_checks.append("Bộ tính toán biến động định lượng ATR và Bollinger Bands hoạt động chính xác.")

        thesis = (
            f"**Báo cáo Kiểm định Thuật toán của Senior Quant Auditor**:\n"
            f"- Trạng thái đồng thuận hội đồng: **{consensus_status}** (Điểm trung bình: {avg_score:.2f}/10, Độ lệch chuẩn: {std_dev:.2f}).\n"
            f"- Cảnh báo rủi ro mô hình: {audit_warning}\n"
            f"- Kiểm định dữ liệu: {len(data_checks)}/3 tiêu chuẩn dữ liệu định lượng đạt chuẩn tuyệt đối."
        )

        return {
            "agent": self.name,
            "consensus_status": consensus_status,
            "score_std_dev": round(std_dev, 2),
            "avg_agent_score": round(avg_score, 2),
            "audit_warning": audit_warning,
            "thesis": thesis
        }
