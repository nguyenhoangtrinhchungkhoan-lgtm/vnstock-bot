"""
Agent: Stanley Druckenmiller & George Soros (Global Macro & Smart Money)
Vai trò: Đọc vị chính sách tiền tệ NHNN, tỷ giá USD/VND, chu kỳ tín dụng & dòng tiền Khối ngoại.
Đặc quyền: QUYẾT ĐỊNH TỶ TRỌNG TIỀN MẶT / CỔ PHIẾU TOÀN DANH MỤC.
"""

class StanleyDruckenmillerAgent:
    def __init__(self):
        self.name = "Stanley Druckenmiller (Vĩ mô & Dòng tiền)"
        self.role = "Chiến lược Vĩ mô, Tỷ giá & Dòng vốn thị trường"

    def analyze(self, macro_data: dict) -> dict:
        sbv_policy = macro_data.get("sbv_rate_trend", "Nới lỏng hỗ trợ")
        usd_vnd = macro_data.get("usd_vnd", "Ổn định")
        vnindex_status = macro_data.get("vn_index_status", "Tích lũy")
        foreign_action = macro_data.get("foreign_net_action", "Cân bằng")

        # Đánh giá chỉ số áp lực vĩ mô (Macro Pressure Index - MPI từ 1 đến 10)
        # Điểm MPI càng thấp -> Vĩ mô càng dễ thở, dòng tiền càng dồi dào
        mpi = 3.5 # Mức tương đối dễ chịu trong bối cảnh lãi suất VN duy trì thấp

        if "thắt chặt" in sbv_policy.lower() or "tăng lãi suất" in sbv_policy.lower():
            mpi += 3.0
        if "căng thẳng" in usd_vnd.lower() or "vượt 25,500" in usd_vnd.lower():
            mpi += 2.0
        if "bán ròng mạnh" in foreign_action.lower():
            mpi += 1.5

        # Xác định tỷ lệ phân bổ Tiền mặt / Cổ phiếu an toàn cho nhà đầu tư
        if mpi <= 4.0:
            macro_environment = "MÔI TRƯỜNG VĨ MÔ THUẬN LỢI (BƠM TIỀN / LÃI SUẤT THẤP)"
            recommended_stock_pct = 80 # Tối đa 80% cổ phiếu
            recommended_cash_pct = 20  # Giữ 20% tiền mặt dự phòng
            macro_score = 8.5
        elif mpi <= 6.5:
            macro_environment = "MÔI TRƯỜNG VĨ MÔ TRUNG TÍNH (PHÂN HÓA DÒNG TIỀN)"
            recommended_stock_pct = 50 # 50% cổ phiếu
            recommended_cash_pct = 50  # 50% tiền mặt
            macro_score = 6.0
        else:
            macro_environment = "MÔI TRƯỜNG VĨ MÔ NGUY HIỂM (THẮT CHẶT / TỶ GIÁ NÓNG)"
            recommended_stock_pct = 20 # Tối đa 20% cổ phiếu phòng thủ
            recommended_cash_pct = 80  # 80% tiền mặt giữ vốn
            macro_score = 3.0

        thesis = (
            f"**Chiến lược Vĩ mô của Stanley Druckenmiller**:\n"
            f"- Đánh giá vĩ mô chung: **{macro_environment}** (Điểm số: {macro_score}/10).\n"
            f"- Chính sách NHNN: {sbv_policy}.\n"
            f"- Tỷ giá USD/VND: {usd_vnd}.\n"
            f"- Dòng tiền khối ngoại & thị trường: {foreign_action}.\n"
            f"- **Khuyến nghị phân bổ tài sản an toàn**: Duy trì **{recommended_stock_pct}% Cổ phiếu** và **{recommended_cash_pct}% Tiền mặt** để linh hoạt trước biến số vĩ mô."
        )

        return {
            "agent": self.name,
            "macro_environment": macro_environment,
            "macro_score": macro_score,
            "recommended_stock_pct": recommended_stock_pct,
            "recommended_cash_pct": recommended_cash_pct,
            "thesis": thesis
        }
