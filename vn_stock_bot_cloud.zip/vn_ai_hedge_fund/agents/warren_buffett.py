"""
Agent: Warren Buffett & Charlie Munger (Value & Economic Moat)
Vai trò: Thẩm định giá trị nội tại, lợi thế cạnh tranh con hào kinh tế (Economic Moat) & chất lượng ban lãnh đạo.
"""

class WarrenBuffettAgent:
    def __init__(self):
        self.name = "Warren Buffett (Giá trị & Moat)"
        self.role = "Thẩm định Lợi thế cạnh tranh & Giá trị dài hạn"

    def analyze(self, company: dict, financials: dict, tech: dict) -> dict:
        symbol = company.get("symbol", "")
        roe_history = financials.get("roe_history", [])
        avg_roe = sum(roe_history) / len(roe_history) if roe_history else 0
        pe = financials.get("pe", 15.0)
        pb = financials.get("pb", 2.0)
        debt_to_equity = financials.get("debt_to_equity", 0.5)
        current_price = tech.get("current_price", 0)

        # 1. Đánh giá Con hào kinh tế (Moat)
        moat_points = 0
        moat_drivers = []

        if avg_roe >= 20.0:
            moat_points += 4
            moat_drivers.append(f"ROE bình quân 3 năm đạt {avg_roe:.1f}% (>20% - Siêu cỗ máy sinh lời)")
        elif avg_roe >= 15.0:
            moat_points += 2
            moat_drivers.append(f"ROE bình quân đạt {avg_roe:.1f}% (Đạt chuẩn)")

        if debt_to_equity <= 0.6:
            moat_points += 3
            moat_drivers.append(f"Cơ cấu vốn cực kỳ an toàn, nợ vay thấp ({debt_to_equity}x VCSH)")
        elif debt_to_equity <= 1.0:
            moat_points += 1
            moat_drivers.append(f"Đòn bẩy ở mức chấp nhận được ({debt_to_equity}x)")

        # Phân tích ngành & thương hiệu
        business_model = company.get("business_model", "").lower()
        if any(w in business_model for w in ["thị phần", "số 1", "toàn cầu", "độc quyền", "dẫn đầu"]):
            moat_points += 3
            moat_drivers.append("Vị thế đầu ngành hoặc sở hữu thương hiệu độc quyền tại Việt Nam")
        else:
            moat_points += 1

        moat_score = min(10, moat_points)
        moat_level = "Con hào rộng (Wide Moat)" if moat_score >= 8 else ("Con hào hẹp (Narrow Moat)" if moat_score >= 5 else "Không có Moat")

        # 2. Định giá hợp lý (Fair Value Margin of Safety)
        # Giả định P/E mục tiêu chuẩn cho doanh nghiệp Wide Moat là 18-22x
        is_cheap = pe <= 16.0
        is_fair = 16.0 < pe <= 22.0
        is_expensive = pe > 22.0

        if is_cheap:
            valuation_status = "Đang rẻ / Dưới giá trị hợp lý (Biên an toàn cao)"
            fair_value = current_price * 1.25
        elif is_fair:
            valuation_status = "Định giá hợp lý so với chất lượng doanh nghiệp"
            fair_value = current_price * 1.10
        else:
            valuation_status = "Đang ở vùng định giá cao, cần đợi nhịp chiết khấu"
            fair_value = current_price * 0.90

        buffett_score = round((moat_score * 0.6) + ((10 if is_cheap else (7 if is_fair else 4)) * 0.4), 1)

        thesis = (
            f"**Đánh giá của Warren Buffett đối với {symbol}**:\n"
            f"- Đẳng cấp Moat: **{moat_level}** (Chấm điểm: {moat_score}/10).\n"
            f"- Năng lực sinh lời: ROE 3 năm đạt {avg_roe:.1f}%, biên lợi nhuận bền vững.\n"
            f"- Định giá: P/E = {pe}x, P/B = {pb}x $\\rightarrow$ {valuation_status}.\n"
            f"- Lời khuyên: {'Xứng đáng là tài sản cốt lõi tích sản dài hạn' if moat_score >= 7 and not is_expensive else 'Cần cân nhắc vùng giá giải ngân thận trọng'}."
        )

        return {
            "agent": self.name,
            "moat_score": f"{moat_score}/10",
            "moat_level": moat_level,
            "buffett_score": buffett_score,
            "avg_roe": round(avg_roe, 1),
            "valuation_status": valuation_status,
            "fair_value_target": round(fair_value, 0),
            "moat_drivers": moat_drivers,
            "thesis": thesis
        }
