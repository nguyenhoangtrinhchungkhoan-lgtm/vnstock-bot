"""
Agent: Richard Wyckoff & Jesse Livermore (Đọc Vị Dòng Tiền Cá Mập & Đội Lái VN)
Vai trò: Thám tử dòng tiền thông minh (Smart Money), giải mã các pha Wyckoff (Tích lũy, Rũ bỏ Spring, Phân phối) & hành vi gom hàng.
"""

class WyckoffWhaleAgent:
    def __init__(self):
        self.name = "Richard Wyckoff (Dòng Tiền Cá Mập & Đội Lái)"
        self.role = "Giải mã Chu kỳ Gom Hàng / Phân Phối của Tay To & Điểm Spring"

    def analyze(self, company: dict, tech: dict) -> dict:
        symbol = company.get("symbol", "")
        vol_ratio = tech.get("volume_ratio", 1.0)
        curr_price = tech.get("current_price", 0)
        ma20 = tech.get("ma20", 0)
        ma50 = tech.get("ma50", 0)
        minervini_score = tech.get("minervini_score", "0/8")
        score = int(minervini_score.split("/")[0])
        rsi = tech.get("rsi_14", 50.0)

        # 1. ĐỊNH DANH PHA WYCKOFF (WYCKOFF ACCUMULATION / DISTRIBUTION SCHEMATIC)
        if score >= 6 and vol_ratio > 1.4:
            phase = "PHA E: MARKUP (BỨT PHÁ ĐẨY GIÁ MẠNH MẼ)"
            whale_action = "CÁ MẬP ĐANG KÉO GIÁ — Dòng tiền lớn đã nhập cuộc dứt khoát"
            whale_score = 9.0
        elif score >= 5:
            phase = "PHA D: SIGN OF STRENGTH (BƯỚC ĐẦU VƯỢT CẢN SOS)"
            whale_action = "DÒNG TIỀN THÔNG MINH BẮT ĐẦU KÍCH HOẠT SÓNG TĂNG"
            whale_score = 7.5
        elif rsi < 35 and vol_ratio < 0.7:
            phase = "PHA C: SPRING / SHAKEOUT (RŨ BỎ CẠN KIỆT NGUỒN CUNG)"
            whale_action = "ĐÈ GIÁ VÉT HÀNG LẦN CUỐI — Nhỏ lẻ bán tháo trong hoảng loạn, Big Boys âm thầm gom"
            whale_score = 8.0 # Cơ hội tuyệt vời để canh điểm nổ
        elif 3 <= score < 5:
            phase = "PHA B: TÍCH LŨY THỬ THÁCH KIÊN NHẪN (BUILDING CAUSE)"
            whale_action = "GOM HÀNG VÙNG HỘP DARVAS — Đội lái quay tay tạo thanh khoản giả để hấp thụ"
            whale_score = 5.5
        else:
            phase = "PHA PHÂN PHỐI HOẶC RƠI TỰ DO (DISTRIBUTION / MARKDOWN)"
            whale_action = "TAY TO ĐÃ RÚT TIỀN — Để mặc nhỏ lẻ tự chơi với nhau trong kênh giảm"
            whale_score = 2.5

        # Dấu hiệu bất thường về khối lượng (Volume Anomaly)
        if vol_ratio > 2.0:
            volume_insight = f"NỔ VOL BẤT THƯỜNG ({vol_ratio:.1f}x so với TB20 phiên). Xác nhận dòng tiền tạo lập có biến động lớn!"
        elif vol_ratio < 0.5:
            volume_insight = f"THANH KHOẢN CẠN KIỆT ({vol_ratio:.1f}x). Nguồn cung bán ra đã gần như biến mất."
        else:
            volume_insight = f"Khối lượng giao dịch ở mức thông thường ({vol_ratio:.1f}x TB20 phiên)."

        thesis = (
            f"**Bắt bài Dòng tiền Cá mập của Richard Wyckoff đối với {symbol}**:\n"
            f"- Định danh cấu trúc Wyckoff: **{phase}**.\n"
            f"- Động thái của Tay To (Smart Money): **{whale_action}**.\n"
            f"- Dấu chân thanh khoản (Volume Footprint): {volume_insight}\n"
            f"- Điểm số Dòng tiền Cá mập: **{whale_score}/10**."
        )

        return {
            "agent": self.name,
            "phase": phase,
            "whale_action": whale_action,
            "volume_insight": volume_insight,
            "whale_score": whale_score,
            "thesis": thesis
        }
