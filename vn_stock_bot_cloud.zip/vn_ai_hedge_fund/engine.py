"""
Vietnam Stock AI Hedge Fund - Engine Cốt Lõi (Executive Dashboard Edition)
Thay thế toàn bộ các đoạn tranh luận dài dòng bằng:
1. Thước đo tiến trình 4 Trụ Cột trực quan (Progress Bars)
2. Kế hoạch tác chiến vốn chi tiết (Action Plan Box)
3. 3 Điểm tựa tăng trưởng cốt lõi vs 3 Rủi ro trọng yếu
"""
import sys
import os
import json
from datetime import datetime

# Đảm bảo mã hóa UTF-8 trên Windows console
try:
    if sys.stdout.encoding.lower() != 'utf-8':
        sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass

from .data_fetcher import VietnamStockDataFetcher
from .agents.michael_burry import MichaelBurryAgent
from .agents.warren_buffett import WarrenBuffettAgent
from .agents.peter_lynch import PeterLynchAgent
from .agents.mark_minervini import MarkMinerviniAgent
from .agents.stanley_druckenmiller import StanleyDruckenmillerAgent
from .agents.jim_simons import JimSimonsAgent
from .agents.howard_marks import HowardMarksAgent
from .agents.nassim_taleb import NassimTalebAgent
from .agents.wyckoff_whale import WyckoffWhaleAgent
from .agents.quant_auditor import QuantAuditorAgent
from .agents.devils_advocate import DevilsAdvocateAgent
from .agents.portfolio_manager import PortfolioManagerAgent
from .portfolio_risk_manager import PortfolioRiskManager

class VietnamAIHedgeFund:
    def __init__(self):
        self.fetcher = VietnamStockDataFetcher()
        self.risk_manager = PortfolioRiskManager()
        self.burry = MichaelBurryAgent()
        self.buffett = WarrenBuffettAgent()
        self.lynch = PeterLynchAgent()
        self.minervini = MarkMinerviniAgent()
        self.druckenmiller = StanleyDruckenmillerAgent()
        self.simons = JimSimonsAgent()
        self.marks = HowardMarksAgent()
        self.taleb = NassimTalebAgent()
        self.wyckoff = WyckoffWhaleAgent()
        self.auditor = QuantAuditorAgent()
        self.devils_advocate = DevilsAdvocateAgent()
        self.pm = PortfolioManagerAgent()

    def get_vnindex_market_overview(self) -> dict:
        tech = self.fetcher.get_technical_analysis("VNINDEX")
        macro = self.fetcher.get_market_macro()

        curr_p = tech.get("current_price", 1700.0)
        ma20 = tech.get("ma20", curr_p)
        ma50 = tech.get("ma50", curr_p)
        ma200 = tech.get("ma200", curr_p)
        rsi = tech.get("rsi_14", 50.0)
        vol_latest = tech.get("volume_latest", 0)
        vol_avg = tech.get("volume_20avg", 1)
        vol_ratio = tech.get("volume_ratio", 1.0)
        bb_upper = tech.get("bb_upper", curr_p * 1.05)
        bb_lower = tech.get("bb_lower", curr_p * 0.95)

        # 1. Xác định Xu Hướng & Chế Độ Thị Trường (Market Regime)
        if curr_p > ma20 and curr_p > ma50:
            regime_badge = "🟢 **THỊ TRƯỜNG UPTREND (XU HƯỚNG TĂNG MẠNH)**"
            regime_desc = "Điểm số nằm trên MA20 và MA50. Dòng tiền thuận lợi, phù hợp mở rộng danh mục."
            recommended_action = "Gia tăng tỷ trọng cổ phiếu lên 70% - 100% NAV. Bắt nhịp các cổ phiếu dẫn dắt (Leader)."
            cash_alloc = "10% - 30% Tiền mặt | 70% - 90% Cổ phiếu"
        elif curr_p > ma50 and curr_p <= ma20:
            regime_badge = "🟡 **THỊ TRƯỜNG SIDEWAY / RUNG LẮC TÍCH LŨY**"
            regime_desc = "VN-Index giằng co thử thách đường MA20, xu hướng trung hạn vẫn giữ trên MA50."
            recommended_action = "Duy trì tỷ trọng an toàn 40% - 50%. Chỉ mua gom khi cổ phiếu chiết khấu về hỗ trợ cứng."
            cash_alloc = "50% Tiền mặt | 50% Cổ phiếu"
        elif rsi < 25.0:
            regime_badge = "🔴 **ĐIỀU CHỈNH GIẢM & QUÁ BÁN CỰC ĐẠI (CHỜ SÓNG HỒI KỸ THUẬT)**"
            regime_desc = f"VN-Index ({curr_p:,.0f}) dưới MA20 ({ma20:,.0f}) và MA50 ({ma50:,.0f}). Tuy nhiên RSI = {rsi} đang ở vùng quá bán sâu, cạn lực xả."
            recommended_action = "Ưu tiên giữ tiền mặt! Không mua đuổi khi giá hồi phục xanh tím. Người có sẵn hàng tận dụng nhịp hồi lướt T0 hạ giá vốn."
            cash_alloc = "70% - 80% Tiền mặt | Tối đa 20% - 30% Cổ phiếu"
        else:
            regime_badge = "🔴 **THỊ TRƯỜNG DOWNTREND (XU HƯỚNG GIẢM RỦI RO)**"
            regime_desc = f"VN-Index gãy các mốc hỗ trợ MA20/MA50. Áp lực bán chiếm ưu thế."
            recommended_action = "Hạ tỷ trọng tối đa, cắt toàn bộ Margin. Giữ chặt tiền mặt đứng ngoài quan sát."
            cash_alloc = "80% - 100% Tiền mặt | 0% - 20% Cổ phiếu"

        # 2. Vùng Hỗ Trợ & Kháng Cự Trọng Yếu
        support_zone = f"{bb_lower:,.0f} - {curr_p:,.0f} điểm"
        resistance_zone = f"{ma20:,.0f} - {ma50:,.0f} điểm"

        # 3. 4 Điều Cực Kỳ Cần Chú Ý (Watchouts)
        watchouts = [
            f"**Cản Kỹ Thuật MA20 ({ma20:,.0f} điểm)**: Mọi nhịp phục hồi ngắn hạn chạm ngưỡng này sẽ gặp áp lực bán kẹp hàng rất lớn. Chú ý không đua lệnh!",
            f"**Thanh Khoản Thị Trường**: Khối lượng đạt {vol_latest:,.0f} cp ({'thấp hơn trung bình ' + str(round(abs(1 - vol_ratio) * 100)) + '%' if vol_ratio < 1 else 'cao hơn trung bình ' + str(round((vol_ratio - 1) * 100)) + '%'}), cho thấy lực cầu bắt đáy còn dè dặt.",
            f"**Kỷ Luật T+2.5 & Bẫy Sóng Hồi (Bull-Trap)**: Khi xu hướng chính đang giảm, mua đuổi ở phiên tăng thứ 2 rất dễ chịu cảnh hàng chưa về tài khoản đã bị bán tháo lỗ nặng.",
            f"**Động Thái Vĩ Mô & Khối Ngoại**: {macro.get('foreign_net_action', 'Khối ngoại phân hóa')} | Tỷ giá: {macro.get('usd_vnd', 'Ổn định')}."
        ]

        # 4. Phản Biện Ngược Dòng (Devil's Advocate)
        if "UPTREND" in regime_badge:
            devils_note = "🚨 CẢNH BÁO: Thị trường tăng hưng phấn nhưng cẩn trọng bẫy thanh khoản cuối sóng, tuyệt đối không full Margin!"
        else:
            devils_note = f"💡 ĐIỂM SÁNG DÀI HẠN: Vùng RSI {rsi} thường là tiền đề cho các con sóng tạo đáy phục hồi lớn trong lịch sử. Nhà đầu tư dài hạn có thể lên danh sách các mã cổ phiếu đầu ngành khỏe hơn thị trường (FPT, SSI, HPG) để gom dần từng phần!"

        return {
            "current_index": curr_p,
            "ma20": ma20,
            "ma50": ma50,
            "ma200": ma200,
            "rsi": rsi,
            "vol_latest": vol_latest,
            "vol_ratio": vol_ratio,
            "support_zone": support_zone,
            "resistance_zone": resistance_zone,
            "regime_badge": regime_badge,
            "regime_desc": regime_desc,
            "recommended_action": recommended_action,
            "cash_alloc": cash_alloc,
            "watchouts": watchouts,
            "devils_note": devils_note,
            "macro": macro
        }

    def run_investment_committee(self, symbol: str) -> dict:
        symbol = symbol.upper().strip()
        
        # 1. Thu thập dữ liệu đa nguồn
        company = self.fetcher.get_company_overview(symbol)
        tech = self.fetcher.get_technical_analysis(symbol)
        financials = self.fetcher.get_financial_health(symbol)
        macro = self.fetcher.get_market_macro()

        # 2. Các chuyên gia AI tính toán chỉ số định lượng
        burry_res = self.burry.analyze(company, financials)
        buffett_res = self.buffett.analyze(company, financials, tech)
        lynch_res = self.lynch.analyze(company, financials, tech)
        minervini_res = self.minervini.analyze(company, tech)
        druckenmiller_res = self.druckenmiller.analyze(macro)
        simons_res = self.simons.analyze(tech)
        marks_res = self.marks.analyze(company, tech, financials)
        taleb_res = self.taleb.analyze(company, tech, financials)
        wyckoff_res = self.wyckoff.analyze(company, tech)

        # 3. Đo lường độ phân hóa (Consensus vs Divergence)
        scores_dict = {
            "buffett": buffett_res.get("buffett_score", 5.0),
            "lynch": lynch_res.get("lynch_score", 5.0),
            "minervini": minervini_res.get("timing_score", 5.0),
            "wyckoff": wyckoff_res.get("whale_score", 5.0),
            "simons": simons_res.get("quant_score", 5.0),
            "taleb": taleb_res.get("taleb_score", 5.0),
            "druckenmiller": druckenmiller_res.get("macro_score", 5.0),
            "marks": marks_res.get("marks_score", 5.0)
        }
        auditor_res = self.auditor.audit_system(scores_dict, tech, financials)

        # 4. Trưởng ban đầu tư phán quyết
        decision = self.pm.arbitrate_comprehensive(
            company=company,
            tech=tech,
            burry_res=burry_res,
            buffett_res=buffett_res,
            lynch_res=lynch_res,
            minervini_res=minervini_res,
            druckenmiller_res=druckenmiller_res,
            simons_res=simons_res,
            marks_res=marks_res,
            taleb_res=taleb_res,
            wyckoff_res=wyckoff_res,
            auditor_res=auditor_res
        )

        # 5. Quản trị rủi ro ngành
        sector_risk = self.risk_manager.evaluate_sector_risk(
            symbol=symbol,
            requested_size_pct=decision["position_size_pct"],
            current_portfolio=None,
            company_info=company
        )
        if sector_risk["is_capped"]:
            decision["position_size_pct"] = sector_risk["approved_size_pct"]

        # 6. SÁT HẠCH & PHẢN BIỆN LỖI SAI (DEVIL'S ADVOCATE & ERROR-HUNTING AUDIT)
        sector = sector_risk.get("sector", "Mặc Định Khác")
        devils_res = self.devils_advocate.review_and_counter(
            symbol=symbol,
            company=company,
            tech=tech,
            financials=financials,
            sector=sector,
            all_agent_scores=scores_dict,
            burry_res=burry_res,
            preliminary_action=decision.get("final_action", "")
        )

        # 7. Tạo báo cáo tác chiến định lượng (Executive Action Dashboard)
        report_md, metrics = self._build_executive_dashboard(
            symbol, company, tech, financials, macro,
            burry_res, buffett_res, lynch_res, minervini_res,
            druckenmiller_res, simons_res, marks_res, taleb_res,
            wyckoff_res, auditor_res, sector_risk, decision,
            devils_res
        )

        agent_details = {
            "burry": burry_res,
            "buffett": buffett_res,
            "lynch": lynch_res,
            "minervini": minervini_res,
            "wyckoff": wyckoff_res,
            "druckenmiller": druckenmiller_res,
            "simons": simons_res,
            "marks": marks_res,
            "taleb": taleb_res,
            "auditor": auditor_res,
            "devils_advocate": devils_res
        }

        return {
            "symbol": symbol,
            "company": company,
            "tech": tech,
            "financials": financials,
            "macro": macro,
            "decision": decision,
            "sector_risk": sector_risk,
            "devils_res": devils_res,
            "report_md": report_md,
            "scores_dict": scores_dict,
            "agent_details": agent_details,
            "auditor": auditor_res,
            "metrics": metrics
        }

    def _render_bar(self, score: float, max_score: float = 10.0) -> str:
        filled = int(round((score / max_score) * 10))
        filled = max(0, min(10, filled))
        return "█" * filled + "░" * (10 - filled)

    def _build_executive_dashboard(self, symbol, company, tech, financials, macro,
                                  burry, buffett, lynch, minervini, druckenmiller,
                                  simons, marks, taleb, wyckoff, auditor, sector_risk, decision,
                                  devils_advocate=None):
        
        now_str = datetime.now().strftime("%d/%m/%Y %H:%M")
        action = decision["final_action"]
        score = decision["composite_score"]
        pos_size = decision["position_size_pct"]
        buy_zone = decision["buy_zone"]
        stop_loss = decision["stop_loss"]
        target = decision["target_price"]
        curr_p = tech.get("current_price", 0)

        # Tính điểm gộp cho 4 trụ cột chính
        score_fa = round((buffett["buffett_score"] + lynch["lynch_score"]) / 2, 1)
        score_ta = round((minervini["timing_score"] + wyckoff["whale_score"]) / 2, 1)
        score_quant = round((simons["quant_score"] + taleb["taleb_score"]) / 2, 1)
        score_macro = round((druckenmiller["macro_score"] + marks["marks_score"]) / 2, 1)

        bar_fa = self._render_bar(score_fa)
        bar_ta = self._render_bar(score_ta)
        bar_quant = self._render_bar(score_quant)
        bar_macro = self._render_bar(score_macro)
        bar_total = self._render_bar(score)

        # Top 3 Điểm Tựa Tăng Trưởng (+)
        pros = []
        if buffett["buffett_score"] >= 7:
            pros.append(f"Doanh nghiệp đầu ngành ({buffett['moat_level']}), ROE 3 năm đạt {buffett['avg_roe']}%.")
        if lynch["lynch_score"] >= 7:
            pros.append(f"Tăng trưởng hấp dẫn PEG = {lynch['peg_ratio']}x (Lợi nhuận +{financials.get('profit_growth')}%, Doanh thu +{financials.get('revenue_growth')}%).")
        if not burry["red_flags"]:
            pros.append(f"Tài chính sạch (Altman Z = {burry['altman_z_score']}), CFO dương dồi dào {financials.get('cfo_history')} tỷ VNĐ.")
        if marks["marks_score"] >= 7:
            pros.append(f"Giá đang ở vùng đáy 52 tuần ({tech.get('cycle_position_pct')}%), chiết khấu sâu.")
        if not pros:
            pros.append("Cổ phiếu đang thu hút dòng tiền giao dịch ngắn hạn.")

        # Top 3 Rủi Ro Trọng Yếu (-)
        cons = []
        if not minervini["is_uptrend"]:
            cons.append(f"Xu hướng kỹ thuật chưa thuận: Giá ({curr_p:,.0f}) dưới MA50 ({tech.get('ma50')}), chưa vào sóng tăng.")
        if burry["red_flags"]:
            cons.append(f"CẢNH BÁO BCTC: {burry['red_flags'][0]}")
        if "RẤT CAO" in tech.get("floor_lock_risk", ""):
            cons.append(f"Rủi ro kẹt sàn T+2.5: Đã có {tech.get('floor_days_in_60d')} phiên sàn gần đây.")
        if "HIGH DIVERGENCE" in auditor["consensus_status"]:
            cons.append(f"Mâu thuẫn trường phái: Cơ bản tốt nhưng Kỹ thuật/Cá mập chưa vào nhịp.")
        if not cons:
            cons.append("Biến động thị trường chung và áp lực chốt lời ngắn hạn.")

        pros_text = "".join(f"- **{p}**\n" for p in pros[:3])
        cons_text = "".join(f"- **{c}**\n" for c in cons[:3])

        breakout_point = decision.get("breakout_point", "Không áp dụng")
        risk_reward = decision.get("risk_reward", "1 : 2.5")
        entry_tactic = decision.get("entry_tactic", "Bắt buộc chia vốn làm 3 đợt (30% - 30% - 40%). Chỉ mua gia tăng khi lô đầu tiên đã về tài khoản an toàn sau $T+2.5$ và có lãi!")

        md = f"""# 🏛️ BÁO CÁO TÁC CHIẾN ĐẦU TƯ: `{symbol}`
**Doanh nghiệp**: **{company.get('company_name')}** ({company.get('exchange', 'HOSE')})  
**Giá hiện tại**: `{curr_p:,.0f} VNĐ` | **Ngành**: `{sector_risk['sector']}` (Trần danh mục: `{sector_risk['max_allowed_sector_pct']}%`)  
**Thời gian cập nhật**: {now_str}

---

## 🎯 KẾT LUẬN & ĐIỂM SỐ TỔNG HỢP

| Chỉ số điều hành | Kết quả thẩm định định lượng |
| :--- | :--- |
| **KHUYẾN NGHỊ HÀNH ĐỘNG** | **{action}** |
| **Điểm Đánh Giá Tổng Hợp** | `{bar_total}` **{score} / 10** |
| **Tỷ Trọng Giải Ngân Tối Đa** | **{pos_size}% NAV** (Đã áp trần rủi ro T+2.5 & Biến động ATR) |
| **Rủi ro Kẹt Sàn T+2.5 (FLI)** | **{tech.get('floor_lock_risk')}** ({tech.get('floor_days_in_60d')} phiên sàn/60 ngày) |

---

## 📊 THƯỚC ĐO 4 TRỤ CỘT ĐỊNH LƯỢNG

* `[FA] Định Giá & Cơ Bản`:     `{bar_fa}` **{score_fa}/10** *(P/E: {financials.get('pe')}x, ROE: {buffett['avg_roe']}%, PEG: {lynch['peg_ratio']}x)*
* `[TA] Kỹ Thuật & Dòng Tiền`: `{bar_ta}` **{score_ta}/10** *(Minervini: {minervini['minervini_score']}, Wyckoff: {wyckoff['phase'][:20]})*
* `[Quant] Định Lượng & Sốc`:   `{bar_quant}` **{score_quant}/10** *(ATR: {simons['atr_pct']}%, Thắng suất: {simons['win_probability_pct']}%, Thoát hàng: {taleb['liquidity_status'][:15]})*
* `[Macro] Vĩ Mô & Chu Kỳ`:    `{bar_macro}` **{score_macro}/10** *(Lãi suất nới lỏng, Vị trí 52 tuần: {tech.get('cycle_position_pct')}%)*

---

## 📋 KẾ HOẠCH TÁC CHIẾN VỐN (ACTION PLAN)

* 💵 **Vùng Mua Gom Chiết Khấu**: `{buy_zone}`
* 🚀 **Điểm Mua Bùng Nổ Vượt Cản**: `{breakout_point}`
* 🛑 **NGƯỠNG CẮT LỖ CỨNG (-7%)**: `{stop_loss}` *(Bảo vệ tài khoản tuyệt đối)*
* 🎯 **Mục Tiêu Chốt Lời Kỳ Vọng**: `{target}`
* ⚖️ **Tỷ Lệ Lợi Nhuận / Rủi Ro (R:R)**: `{risk_reward}`
* 🛡️ **Chiến Lược Đi Lệnh An Toàn**:  
  > *{entry_tactic}*

---

## 🛡️ HỘI ĐỒNG PHẢN BIỆN CHÉO & SÁT HẠCH LỖI SAI (DEVIL'S ADVOCATE)
* **Trạng thái thẩm định**: **{devils_advocate.get('status', 'CHUẨN XÁC 100%') if devils_advocate else 'CHUẨN XÁC 100%'}**
* **Điểm số tin cậy logic**: **{devils_advocate.get('sanity_score', 10.0) if devils_advocate else 10.0} / 10**
"""
        if devils_advocate and devils_advocate.get("corrections_applied"):
            md += "\n### ⚠️ Phát Hiện & Tự Động Hiệu Chỉnh Xung Đột:\n"
            for corr in devils_advocate["corrections_applied"]:
                md += f"- ✅ {corr}\n"

        if devils_advocate and devils_advocate.get("contrarian_points"):
            md += "\n### 🔍 Góc Nhìn Phản Biện Ngược Dòng (Contrarian View):\n"
            for cp in devils_advocate["contrarian_points"]:
                md += f"- 💡 {cp}\n"

        md += f"""
---

## 💡 ĐIỂM TỰA TĂNG TRƯỞNG (+) VS RỦI RO TRỌNG YẾU (-)

### ✅ 3 Điểm Tựa Tăng Trưởng:
{pros_text}
### ⚠️ 3 Rủi Ro Trọng Yếu Phải Né:
{cons_text}
---
*Bản tin tác chiến cô đọng bởi Vietnam AI Hedge Fund — Tối giản, Kỷ luật và Bảo vệ vốn.*
"""
        metrics = {
            "score_fa": score_fa,
            "score_ta": score_ta,
            "score_quant": score_quant,
            "score_macro": score_macro,
            "bar_fa": bar_fa,
            "bar_ta": bar_ta,
            "bar_quant": bar_quant,
            "bar_macro": bar_macro,
            "bar_total": bar_total,
            "pros": pros[:3],
            "cons": cons[:3],
            "devils_advocate": devils_advocate or {}
        }
        return md, metrics
