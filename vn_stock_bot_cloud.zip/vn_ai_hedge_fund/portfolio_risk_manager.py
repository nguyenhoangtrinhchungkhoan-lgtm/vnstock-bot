"""
Portfolio Risk Manager - Quản Trị Tương Quan Danh Mục & Ngưỡng Chặn Ngành (Sector Exposure Cap)
Khắc phục Lỗ hổng 4: Ngăn chặn việc dồn quá nhiều vốn vào một ngành đơn lẻ (BĐS, Thép, Chứng khoán)
gây sụp đổ danh mục khi sóng ngành đảo chiều.
"""

class PortfolioRiskManager:
    # Bảng phân loại ngành chuẩn ICB cho các mã phổ biến trên HOSE / HNX
    SECTOR_MAPPING = {
        # Bất động sản (Real Estate) - Max 25%
        "VHM": "Bất Động Sản", "NVL": "Bất Động Sản", "DIG": "Bất Động Sản", 
        "PDR": "Bất Động Sản", "DXG": "Bất Động Sản", "CEO": "Bất Động Sản", 
        "KDH": "Bất Động Sản", "NLG": "Bất Động Sản", "VRE": "Bất Động Sản", "VIC": "Bất Động Sản",
        # Ngân hàng (Banking) - Max 30%
        "VCB": "Ngân Hàng", "TCB": "Ngân Hàng", "MBB": "Ngân Hàng", 
        "ACB": "Ngân Hàng", "CTG": "Ngân Hàng", "BID": "Ngân Hàng", 
        "VPB": "Ngân Hàng", "HDB": "Ngân Hàng", "STB": "Ngân Hàng", "LPB": "Ngân Hàng",
        # Chứng khoán (Securities) - Max 20%
        "SSI": "Chứng Khoán", "VND": "Chứng Khoán", "VCI": "Chứng Khoán", 
        "HCM": "Chứng Khoán", "SHS": "Chứng Khoán", "MBS": "Chứng Khoán", "FTS": "Chứng Khoán",
        # Thép & Vật liệu (Steel & Materials) - Max 20%
        "HPG": "Thép & Vật Liệu", "HSG": "Thép & Vật Liệu", "NKG": "Thép & Vật Liệu",
        # Công nghệ & Viễn thông (Technology) - Max 25%
        "FPT": "Công Nghệ & Viễn Thông", "CMG": "Công Nghệ & Viễn Thông", "ELC": "Công Nghệ & Viễn Thông",
        # Bán lẻ & Tiêu dùng (Retail & Consumer) - Max 25%
        "MWG": "Bán Lẻ & Tiêu Dùng", "FRT": "Bán Lẻ & Tiêu Dùng", "PNJ": "Bán Lẻ & Tiêu Dùng", 
        "DGW": "Bán Lẻ & Tiêu Dùng", "VNM": "Bán Lẻ & Tiêu Dùng", "MSN": "Bán Lẻ & Tiêu Dùng",
        # Dầu khí & Năng lượng (Oil & Energy) - Max 20%
        "GAS": "Dầu Khí & Năng Lượng", "PVD": "Dầu Khí & Năng Lượng", "PVS": "Dầu Khí & Năng Lượng", 
        "BSR": "Dầu Khí & Năng Lượng", "POW": "Dầu Khí & Năng Lượng", "REE": "Dầu Khí & Năng Lượng"
    }

    # Giới hạn tỷ trọng tối đa cho từng ngành để bảo vệ an toàn danh mục
    SECTOR_LIMITS = {
        "Ngân Hàng": 30,
        "Bất Động Sản": 25,
        "Chứng Khoán": 20,
        "Thép & Vật Liệu": 20,
        "Công Nghệ & Viễn Thông": 25,
        "Bán Lẻ & Tiêu Dùng": 25,
        "Dầu Khí & Năng Lượng": 20,
        "Mặc Định Khác": 20
    }

    def __init__(self):
        pass

    def get_stock_sector(self, symbol: str, company_info: dict = None) -> str:
        symbol = symbol.upper().strip()
        if symbol in self.SECTOR_MAPPING:
            return self.SECTOR_MAPPING[symbol]
        
        # Nếu không có trong danh sách cố định, suy luận từ thông tin công ty
        if company_info:
            biz = (company_info.get("business_model", "") + " " + company_info.get("industry", "")).lower()
            if any(w in biz for w in ["bất động sản", "địa ốc", "nhà ở", "khu đô thị"]):
                return "Bất Động Sản"
            elif any(w in biz for w in ["ngân hàng", "tín dụng", "tiền gửi"]):
                return "Ngân Hàng"
            elif any(w in biz for w in ["chứng khoán", "môi giới chứng khoán"]):
                return "Chứng Khoán"
            elif any(w in biz for w in ["thép", "tôn mạ", "kim loại"]):
                return "Thép & Vật Liệu"
            elif any(w in biz for w in ["phần mềm", "công nghệ", "viễn thông"]):
                return "Công Nghệ & Viễn Thông"
            elif any(w in biz for w in ["bán lẻ", "siêu thị", "sữa", "thực phẩm"]):
                return "Bán Lẻ & Tiêu Dùng"
            elif any(w in biz for w in ["dầu khí", "năng lượng", "xăng dầu", "điện"]):
                return "Dầu Khí & Năng Lượng"
        return "Mặc Định Khác"

    def evaluate_sector_risk(self, symbol: str, requested_size_pct: int, current_portfolio: dict = None, company_info: dict = None) -> dict:
        """
        Kiểm tra xem việc mua thêm mã này có làm danh mục vi phạm trần tỷ trọng ngành không.
        current_portfolio format ví dụ: {"FPT": 15, "MWG": 10}
        """
        sector = self.get_stock_sector(symbol, company_info)
        max_allowed_sector_pct = self.SECTOR_LIMITS.get(sector, 20)

        # Tính tỷ trọng hiện tại của ngành này trong danh mục
        current_sector_pct = 0
        if current_portfolio:
            for s, weight in current_portfolio.items():
                if self.get_stock_sector(s) == sector:
                    current_sector_pct += weight

        remaining_room = max(0, max_allowed_sector_pct - current_sector_pct)
        approved_size_pct = min(requested_size_pct, remaining_room)

        is_capped = approved_size_pct < requested_size_pct

        if is_capped:
            warning_msg = (
                f"CẢNH BÁO TẬP TRUNG NGÀNH: Ngành {sector} đang chiếm {current_sector_pct}% NAV. "
                f"Trần giới hạn cho ngành này là {max_allowed_sector_pct}%. "
                f"Tỷ trọng mua của {symbol} bị giới hạn tự động từ {requested_size_pct}% xuống còn {approved_size_pct}% NAV để bảo vệ danh mục."
            )
        else:
            warning_msg = f"Tỷ trọng ngành {sector} an toàn ({current_sector_pct + approved_size_pct}% <= {max_allowed_sector_pct}% trần cho phép)."

        return {
            "sector": sector,
            "max_allowed_sector_pct": max_allowed_sector_pct,
            "current_sector_pct": current_sector_pct,
            "approved_size_pct": approved_size_pct,
            "is_capped": is_capped,
            "warning_msg": warning_msg
        }
