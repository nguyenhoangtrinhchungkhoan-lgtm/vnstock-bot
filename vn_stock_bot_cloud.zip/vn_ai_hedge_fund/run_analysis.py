"""
CLI Runner for Vietnam Stock AI Hedge Fund
Chạy phân tích đa tầng trên các mã cổ phiếu TTCK Việt Nam.
"""
import sys
import os
import argparse

# Đảm bảo mã hóa UTF-8 trên Windows console
try:
    if sys.stdout.encoding.lower() != 'utf-8':
        sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass

# Đưa thư mục cha vào sys.path để import tương đối
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from vn_ai_hedge_fund.engine import VietnamAIHedgeFund

def main():
    parser = argparse.ArgumentParser(description="Vietnam Stock AI Hedge Fund - Multi-Agent Investment Analyzer")
    parser.add_argument("--symbol", type=str, default="FPT", help="Mã cổ phiếu cần phân tích (VD: FPT, HPG, VNM, SSI...)")
    parser.add_argument("--save", action="store_true", help="Lưu báo cáo phân tích ra file Markdown")
    args = parser.parse_args()

    symbol = args.symbol.upper().strip()
    print("=" * 70)
    print("🇻🇳 VIETNAM STOCK AI HEDGE FUND — MULTI-AGENT QUANT & VALUE SYSTEM")
    print("=" * 70)
    
    fund = VietnamAIHedgeFund()
    result = fund.run_investment_committee(symbol)
    
    print("\n" + result["report_md"])
    print("=" * 70)
    
    if args.save:
        filename = f"Bao_Cao_Phan_Tich_{symbol}.md"
        with open(filename, "w", encoding="utf-8") as f:
            f.write(result["report_md"])
        print(f"\n[✓] Đã xuất báo cáo đầu tư chi tiết ra file: {os.path.abspath(filename)}")

if __name__ == "__main__":
    main()
