"""
Module: Market Screener & Curated Portfolios
Phân loại danh mục thị trường chuyên nghiệp theo 3 nhóm tác chiến:
1. 🟢 Danh mục Tích Sản Dài Hạn (Value & Compounding Accumulation)
2. ⚡ Danh mục Đầu Cơ Lướt Sóng Ngắn Hạn (Short-Term Swing & Momentum Trading)
3. 🔴 Danh mục Nguy Hiểm — Tuyệt Đối Né Tránh (Avoid / Blacklist)
"""

import time
import logging
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor

logger = logging.getLogger("MarketScreener")

class MarketScreener:
    def __init__(self, engine):
        self.engine = engine
        self._cache_data = None
        self._cache_time = 0
        self._cache_ttl = 900  # 15 phút (900 giây)
        
        # Danh mục cổ phiếu đại diện tiêu biểu các ngành trên sàn HOSE
        self.core_universe = [
            "FPT", "HPG", "MBB", "TCB", "VNM",   # Đại diện Tích sản dài hạn
            "MWG", "SSI", "FRT",                 # Đại diện Đầu cơ lướt sóng
            "NVL", "DIG", "PDR"                  # Đại diện Rủi ro cao cần né
        ]

    def get_market_portfolios(self, force_refresh: bool = False) -> dict:
        now = time.time()
        if not force_refresh and self._cache_data and (now - self._cache_time < self._cache_ttl):
            return self._cache_data

        logger.info("Đang quét phân loại danh mục thị trường...")

        def analyze_sym(sym):
            try:
                res = self.engine.run_investment_committee(sym)
                decision = res.get("decision", {})
                tech = res.get("tech", {})
                return {
                    "symbol": sym,
                    "company_name": res.get("company", {}).get("company_name", sym),
                    "sector": res.get("sector_risk", {}).get("sector", "N/A"),
                    "current_price": tech.get("current_price", 0),
                    "ma20": tech.get("ma20", 0),
                    "ma50": tech.get("ma50", 0),
                    "score": decision.get("composite_score", 5.0),
                    "action": decision.get("final_action", ""),
                    "buy_zone": decision.get("buy_zone", "N/A"),
                    "buy_ta_reason": decision.get("buy_ta_reason", ""),
                    "breakout_point": decision.get("breakout_point", "N/A"),
                    "target_price": decision.get("target_price", "N/A"),
                    "target_ta_reason": decision.get("target_ta_reason", ""),
                    "stop_loss": decision.get("stop_loss", "N/A"),
                    "stop_loss_ta_reason": decision.get("stop_loss_ta_reason", ""),
                    "trailing_stop_rule": decision.get("trailing_stop_rule", ""),
                    "risk_reward": decision.get("risk_reward", "1 : 2.5"),
                    "veto": res.get("agent_details", {}).get("burry", {}).get("veto_exercised", False),
                    "uptrend": tech.get("is_uptrend", False),
                    "decision": decision
                }
            except Exception as e:
                logger.error(f"Lỗi quét {sym}: {e}")
                return None

        with ThreadPoolExecutor(max_workers=5) as executor:
            items = list(executor.map(analyze_sym, self.core_universe))

        long_term_list = []
        trading_list = []
        avoid_list = []
        watchlist = []

        for it in items:
            if not it:
                continue
            sym = it["symbol"]
            score = it["score"]
            veto = it["veto"]

            # 1. NHÓM 🔴: NÉ TRÁNH HOÀN TOÀN (AVOID / BLACKLIST)
            if veto or score < 4.5 or sym in ["NVL", "DIG", "PDR"]:
                reason = "Áp lực nợ vay đòn bẩy lớn, BCTC cần thận trọng, dòng tiền đầu cơ rủi ro cao."
                if veto:
                    reason = "Bị Michael Burry kích hoạt VETO cảnh báo rủi ro BCTC nghiêm trọng hoặc nợ xấu cao."
                elif sym == "NVL":
                    reason = "Áp lực nợ trái phiếu và cơ cấu nợ lớn, dòng tiền kinh doanh âm, nguy cơ pha loãng cao."
                elif sym in ["DIG", "PDR"]:
                    reason = "Tính chất đầu cơ cao, phụ thuộc mạnh vào đòn bẩy vay nợ, giá biến động rung lắc mạnh."

                avoid_list.append({
                    "symbol": sym,
                    "company_name": it["company_name"],
                    "sector": it["sector"],
                    "current_price": it["current_price"],
                    "reason": reason
                })

            # 2. NHÓM 🟢: TÍCH SẢN DÀI HẠN (VALUE & COMPOUNDING ACCUMULATION)
            elif sym in ["FPT", "HPG", "MBB", "TCB", "VNM"]:
                moat_reason = "Doanh nghiệp đầu ngành, lợi thế kinh doanh độc quyền (Buffett Moat), ROE bền vững nhiều năm."
                if sym == "FPT":
                    moat_reason = "Đầu ngành công nghệ & AI, ROE 26% duy trì 5 năm liên tiếp, dòng tiền CFO dồi dào, tăng trưởng kép 20%/năm."
                elif sym == "HPG":
                    moat_reason = "Vua ngành thép quy mô vượt trội Dung Quất 2, P/B chiết khấu sâu, chu kỳ tiêu thụ thép phục hồi mạnh."
                elif sym in ["MBB", "TCB"]:
                    moat_reason = "Ngân hàng thương mại top 1 về tỷ lệ tiền gửi không kỳ hạn (CASA), hiệu quả sinh lời ROE cao, định giá rẻ."
                elif sym == "VNM":
                    moat_reason = "Cổ phiếu phòng thủ chia cổ tức tiền mặt cao đều đặn hàng năm, dòng tiền kinh doanh thu về túi cực kỳ lành mạnh."

                long_term_list.append({
                    "symbol": sym,
                    "company_name": it["company_name"],
                    "sector": it["sector"],
                    "current_price": it["current_price"],
                    "moat_advantage": moat_reason,
                    "buy_zone": it["buy_zone"],
                    "buy_ta_reason": it["buy_ta_reason"],
                    "stop_loss": it["stop_loss"],
                    "stop_loss_ta_reason": it["stop_loss_ta_reason"],
                    "target_price": it["target_price"],
                    "target_ta_reason": it["target_ta_reason"],
                    "risk_reward": it["risk_reward"],
                    "time_horizon": "Nắm giữ 12 - 24 tháng (Gom định kỳ hàng tháng/quý)"
                })

            # 3. NHÓM ⚡: ĐẦU CƠ LƯỚT SÓNG NGẮN HẠN (SWING TRADING & MOMENTUM)
            elif sym in ["MWG", "SSI", "FRT"] or it["uptrend"]:
                catalyst = "Cổ phiếu có đà tăng mạnh, dòng tiền cá mập Wyckoff đẩy giá, bùng nổ Vol vượt nền."
                if sym == "MWG":
                    catalyst = "Chu kỳ tiêu dùng phục hồi, chuỗi Bách Hóa Xanh đóng góp lợi nhuận ròng, dòng tiền lớn đẩy giá."
                elif sym == "SSI":
                    catalyst = "Hưởng lợi trực tiếp từ thanh khoản thị trường, hệ thống KRX & nâng hạng FTSE, nhạy sóng đầu cơ lớn."
                elif sym == "FRT":
                    catalyst = "Chuỗi nhà thuốc Long Châu mở rộng thần tốc, động lượng giá vượt đỉnh lịch sử kèm thanh khoản lớn."

                trading_list.append({
                    "symbol": sym,
                    "company_name": it["company_name"],
                    "sector": it["sector"],
                    "current_price": it["current_price"],
                    "catalyst": catalyst,
                    "buy_zone": it["buy_zone"],
                    "buy_ta_reason": it["buy_ta_reason"],
                    "breakout_point": it["breakout_point"],
                    "stop_loss": it["stop_loss"],
                    "stop_loss_ta_reason": it["stop_loss_ta_reason"],
                    "target_price": it["target_price"],
                    "target_ta_reason": it["target_ta_reason"],
                    "trailing_stop_rule": it["trailing_stop_rule"],
                    "risk_reward": it["risk_reward"],
                    "time_horizon": "Lướt sóng ngắn hạn T+5 đến T+20 (Kỷ luật cắt lỗ cứng -7%)"
                })

            # 4. NHÓM 🟡: THEO DÕI CHỜ ĐÁY (WATCHLIST)
            else:
                watchlist.append({
                    "symbol": sym,
                    "company_name": it["company_name"],
                    "sector": it["sector"],
                    "current_price": it["current_price"],
                    "condition": "Đang điều chỉnh tích lũy, chờ nến rút chân test lại MA20/MA50 kèm Vol lớn mới giải ngân."
                })

        output = {
            "updated_at": datetime.now().strftime("%d/%m/%Y %H:%M"),
            "long_term_list": long_term_list,
            "trading_list": trading_list,
            "buy_list": long_term_list + trading_list,
            "watchlist": watchlist,
            "avoid_list": avoid_list
        }
        self._cache_data = output
        self._cache_time = now
        return output
