"""
Telegram Bot for Vietnam Stock AI Hedge Fund
Token: 8699111146:AAGb2oeGyr01IYhP1mTxr5Oh9CQeb5MZj3M
Username: @trolychungandtrinh_bot
Tác giả: Nguyễn Hoàng Trịnh (TikTok: @nguyenhoangtrinh4)
STK Ủng Hộ: TPBank 10002654317 NGUYEN HOANG TRINH
"""
import sys
import os
import asyncio
import logging
from datetime import datetime

# Đảm bảo mã hóa UTF-8 trên Windows console
try:
    if sys.stdout.encoding.lower() != 'utf-8':
        sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass

# Đưa thư mục cha vào sys.path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    Message, CallbackQuery, 
    InlineKeyboardMarkup, InlineKeyboardButton,
    ReplyKeyboardMarkup, KeyboardButton,
    FSInputFile
)
from aiogram.enums import ParseMode

from vn_ai_hedge_fund.engine import VietnamAIHedgeFund
from vn_ai_hedge_fund.backtest import VietnamStockBacktester
from vn_ai_hedge_fund.screener import MarketScreener

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "8699111146:AAGb2oeGyr01IYhP1mTxr5Oh9CQeb5MZj3M")
DONATE_QR_PATH = os.path.join(current_dir, "assets", "tpbank_qr.png")

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger("VNStockAIBot")

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()
fund = VietnamAIHedgeFund()
backtester = VietnamStockBacktester()
screener = MarketScreener(fund)

def get_main_keyboard():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📊 Xu Hướng VN-Index"), KeyboardButton(text="🎯 Danh Mục Mua & Né Tránh")],
            [KeyboardButton(text="FPT"), KeyboardButton(text="HPG"), KeyboardButton(text="SSI")],
            [KeyboardButton(text="VNM"), KeyboardButton(text="NVL"), KeyboardButton(text="MWG")],
            [KeyboardButton(text="ℹ️ Hướng Dẫn Cho F0 (Dễ Hiểu)"), KeyboardButton(text="🧠 10 Siêu AI Là Gì?")],
            [KeyboardButton(text="☕ Ủng Hộ Tác Giả (TPBank)"), KeyboardButton(text="📱 TikTok Admin (Follow Me ❤️)")]
        ],
        resize_keyboard=True
    )

def get_position_selection_keyboard(symbol: str):
    """Bước 1: Bàn phím chọn Vị thế (Mua mới vs Đang cầm hàng)"""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🟢 Tôi Muốn Mua Mới", callback_data=f"buyer_{symbol}"),
                InlineKeyboardButton(text="🔵 Tôi Đang Cầm Hàng", callback_data=f"holder_{symbol}")
            ]
        ]
    )

def get_style_selection_keyboard(symbol: str, position: str = "buyer"):
    """Bước 2: Bàn phím chọn Mục tiêu (Dài hạn tích sản vs Lướt sóng ngắn hạn)"""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="💎 Đầu Tư Tích Sản Dài Hạn", callback_data=f"plan_{position}_long_{symbol}"),
                InlineKeyboardButton(text="⚡ Lướt Sóng Ngắn Hạn (T+)", callback_data=f"plan_{position}_short_{symbol}")
            ],
            [
                InlineKeyboardButton(text="↩️ Quay Lại Chọn Vị Thế", callback_data=f"select_pos_{symbol}")
            ]
        ]
    )

def get_action_inline_keyboard(symbol: str, position: str = "buyer", style: str = "short"):
    """Bàn phím đầy đủ hiển thị sau khi đã xem khuyến nghị tác chiến"""
    # Nút chuyển đổi phong cách (Dài hạn <-> Ngắn hạn)
    if style == "short":
        style_btn = InlineKeyboardButton(text="💎 Đổi Sang: Đầu Tư Dài Hạn", callback_data=f"plan_{position}_long_{symbol}")
    else:
        style_btn = InlineKeyboardButton(text="⚡ Đổi Sang: Lướt Sóng Ngắn Hạn", callback_data=f"plan_{position}_short_{symbol}")

    # Nút chuyển đổi vị thế (Mua mới <-> Đang cầm hàng)
    if position == "buyer":
        pos_btn = InlineKeyboardButton(text="🔵 Đổi Sang: Tôi Đang Cầm Hàng", callback_data=f"plan_holder_{style}_{symbol}")
    else:
        pos_btn = InlineKeyboardButton(text="🟢 Đổi Sang: Tôi Muốn Mua Mới", callback_data=f"plan_buyer_{style}_{symbol}")

    return InlineKeyboardMarkup(
        inline_keyboard=[
            [style_btn],
            [pos_btn],
            [
                InlineKeyboardButton(text="📊 Kiểm Tra Lịch Sử 5 Năm", callback_data=f"backtest_{symbol}"),
                InlineKeyboardButton(text="🔍 Xem 10 Chuyên Gia Nói Gì", callback_data=f"audit_{symbol}")
            ],
            [
                InlineKeyboardButton(text="🛡️ Soi Nợ Vay & Rủi Ro Kẹt Sàn", callback_data=f"risk_{symbol}"),
                InlineKeyboardButton(text="📋 Báo Cáo Chuyên Sâu", callback_data=f"full_{symbol}")
            ],
            [
                InlineKeyboardButton(text="☕ Mời Tác Giả Ly Cà Phê ❤️", callback_data="donate"),
                InlineKeyboardButton(text="📱 TikTok @nguyenhoangtrinh4", url="https://www.tiktok.com/@nguyenhoangtrinh4")
            ]
        ]
    )

async def send_donate_info(chat_id: int):
    donate_caption = (
        "☕ **ỦNG HỘ TÁC GIẢ PHÁT TRIỂN BOT** ❤️\n\n"
        "Chào bạn, mình là **Nguyễn Hoàng Trịnh** (TikTok: [@nguyenhoangtrinh4](https://www.tiktok.com/@nguyenhoangtrinh4))!\n\n"
        "Bot này được mình xây dựng hoàn toàn **MIỄN PHÍ** để phục vụ các bạn theo dõi kênh TikTok và cộng đồng nhà đầu tư mới (F0) "
        "có một công cụ phân tích khách quan, **bảo vệ túi tiền** trước khi nghĩ đến việc kiếm lời.\n\n"
        "Nếu bot giúp bạn tránh được các bẫy xào nấu BCTC, né đu đỉnh kẹp sàn và đầu tư tự tin hơn, bạn có thể **mời mình một ly cà phê** "
        "để tiếp thêm động lực duy trì server, cập nhật dữ liệu và nghiên cứu thêm nhiều tính năng hay nhé:\n\n"
        "🏦 **Ngân hàng**: **TPBank (Ngân hàng Tiên Phong)**\n"
        "💳 **Số tài khoản**: `10002654317`\n"
        "👤 **Chủ tài khoản**: **NGUYEN HOANG TRINH**\n"
        "📝 **Nội dung gợi ý**: *Ung ho bot + Tên TikTok của bạn*\n\n"
        "*(Bạn có thể quét mã VietQR ở trên để chuyển khoản nhanh chóng tiện lợi)*\n\n"
        "Cảm ơn tấm lòng và sự ủng hộ của bạn rất nhiều! Chúc bạn và gia đình luôn mạnh khỏe, đầu tư kỷ luật và gặt hái nhiều thắng lợi! 🚀💎"
    )
    if os.path.exists(DONATE_QR_PATH):
        try:
            photo = FSInputFile(DONATE_QR_PATH)
            await bot.send_photo(chat_id=chat_id, photo=photo, caption=donate_caption, parse_mode=ParseMode.MARKDOWN)
            return
        except Exception as e:
            logger.error(f"Lỗi gửi ảnh QR: {e}")
    await bot.send_message(chat_id=chat_id, text=donate_caption, parse_mode=ParseMode.MARKDOWN)

@dp.message(CommandStart())
async def cmd_start(message: Message):
    welcome_text = (
        "🏛️ **CHÀO MỪNG BẠN ĐẾN VỚI VIETNAM AI HEDGE FUND** 🏛️\n"
        "*(Hội Đồng 10 Siêu AI Phân Tích Cổ Phiếu Dành Cho Mọi Người)*\n\n"
        "✨ **Sáng lập & Phát triển bởi**: **Nguyễn Hoàng Trịnh**\n"
        "📱 **Kênh TikTok chính thức**: [@nguyenhoangtrinh4](https://www.tiktok.com/@nguyenhoangtrinh4) *(Xin mọi người 1 follow ạ ❤️)*\n\n"
        "👋 Chào các bạn theo dõi kênh của mình! Bot này được thiết kế mô phỏng thuật toán quỹ đầu tư chuyên nghiệp nhưng được "
        "**chuyển thể sang ngôn ngữ cực kỳ dễ hiểu**, giúp các bạn mới (F0) tránh các cạm bẫy mất tiền phổ biến:\n"
        "• 🛑 **Tránh bắt dao rơi**: Cấm mua cổ phiếu đang trong sóng giảm (Downtrend).\n"
        "• 🕵️ **Phát hiện lãi ảo**: Soi tận gốc sổ sách, bóc trần công ty nợ ngập đầu, dòng tiền kinh doanh âm.\n"
        "• ⚠️ **Cảnh báo kẹt sàn T+2.5**: Nhận diện cổ phiếu hay bị nhốt sàn mất thanh khoản không bán được.\n\n"
        "👉 **Cách dùng cực dễ**: Chỉ cần gõ mã cổ phiếu (VD: `FPT`, `HPG`, `SSI`, `NVL`...) hoặc bấm các nút bên dưới để bắt đầu ngay!"
    )
    await message.answer(welcome_text, parse_mode=ParseMode.MARKDOWN, reply_markup=get_main_keyboard())

@dp.message(F.text == "☕ Ủng Hộ Tác Giả (TPBank)")
@dp.message(Command("donate"))
@dp.message(Command("ungho"))
async def cmd_donate_handler(message: Message):
    await send_donate_info(message.chat.id)

@dp.callback_query(F.data == "donate")
async def cb_donate_handler(callback: CallbackQuery):
    try:
        await callback.answer()
    except Exception:
        pass
    await send_donate_info(callback.message.chat.id)

@dp.message(F.text == "📱 TikTok Admin (Follow Me ❤️)")
async def cmd_tiktok(message: Message):
    tiktok_text = (
        "✨ **KÊNH TIKTOK CHÍNH THỨC CỦA TÁC GIẢ** ✨\n\n"
        "👤 **Nguyễn Hoàng Trịnh**\n"
        "📱 **TikTok ID**: [@nguyenhoangtrinh4](https://www.tiktok.com/@nguyenhoangtrinh4)\n"
        "🔗 **Link truy cập**: https://www.tiktok.com/@nguyenhoangtrinh4\n\n"
        "Cảm ơn mọi người đã tin tưởng và sử dụng bot! Rất mong được mọi người ủng hộ **1 follow** trên kênh TikTok để cùng theo dõi "
        "các video phân tích cổ phiếu, kiến thức tài chính thực chiến và cập nhật các tính năng AI mới nhất nhé! Chúc mọi người đầu tư đại thắng! 🚀❤️"
    )
    await message.answer(tiktok_text, parse_mode=ParseMode.MARKDOWN)

@dp.message(Command("help"))
@dp.message(F.text == "ℹ️ Hướng Dẫn Cho F0 (Dễ Hiểu)")
@dp.message(F.text == "ℹ️ Hướng Dẫn")
async def cmd_help(message: Message):
    help_text = (
        "📖 **CẨM NANG ĐẦU TƯ CHO NGƯỜI MỚI (F0) — CỰC DỄ HIỂU**\n\n"
        "1️⃣ **Cách tra cứu cổ phiếu**:\n"
        "• Gõ thẳng mã 3 chữ cái vào ô chat (VD: `FPT`, `HPG`, `SSI`, `VNM`...)\n"
        "• Hoặc gõ lệnh: `/pt <MÃ>` (VD: `/pt SSI`)\n\n"
        "2️⃣ **Quy tắc Đèn Giao Thông của Bot**:\n"
        "• 🟢 **ĐÈN XANH (CÓ THỂ MUA GOM)**: Điểm cao $\\ge 7/10$, doanh nghiệp tốt, xu hướng tăng $\\rightarrow$ An tâm mua gom từng phần.\n"
        "• 🟡 **ĐÈN VÀNG (CHỜ ĐỢI - CHƯA VÀO TIỀN)**: Công ty tốt nhưng giá đang chỉnh hoặc dòng tiền chưa vào $\\rightarrow$ Kiên nhẫn chờ, không vội vàng.\n"
        "• 🔴 **ĐÈN ĐỎ (TUYỆT ĐỐI NÉ TRÁNH)**: Bị cảnh báo nợ xấu, BCTC lãi ảo hoặc nguy cơ kẹt sàn $\\rightarrow$ Tuyệt đối không mua kẻo mất tiền oan!\n\n"
        "3️⃣ **Quy tắc sống còn bảo vệ vốn (Bí kíp F0)**:\n"
        "• **Không All-in**: Có 100 triệu, chỉ mua tối đa 20 - 25 triệu cho 1 mã.\n"
        "• **Bí kíp đi tiền 3 lần (30% - 30% - 40%)**: Mua trước 30%. Chờ 2.5 ngày hàng về tài khoản CÓ LÃI mới mua tiếp 30%. Tuyệt đối không mua trung bình giá xuống!\n"
        "• **Kỷ luật Cắt Lỗ Cứng -7%**: Nếu mua sai bị lỗ 7%, BÁN NGAY lập tức để giữ tiền, không bao giờ gồng lỗ!\n\n"
        "✨ *Bot by Nguyễn Hoàng Trịnh | TikTok: [@nguyenhoangtrinh4](https://www.tiktok.com/@nguyenhoangtrinh4)*\n"
        "☕ *Ủng hộ admin: TPBank `10002654317` (NGUYEN HOANG TRINH)*"
    )
    await message.answer(help_text, parse_mode=ParseMode.MARKDOWN)

@dp.message(F.text == "🧠 10 Siêu AI Là Gì?")
@dp.message(F.text == "📊 Giới Thiệu 10 AI")
async def cmd_intro(message: Message):
    text = (
        "🧠 **10 CHUYÊN GIA AI BẢO VỆ TÚI TIỀN CỦA BẠN NHƯ THẾ NÀO?**\n\n"
        "1. 🕵️ **Michael Burry (Thám Tử BCTC)**: Soi xem công ty có làm ăn thật không hay xào nấu lãi ảo. Nếu phát hiện gian lận $\\rightarrow$ Kích hoạt VETO huỷ mua ngay!\n"
        "2. 🦉 **Warren Buffett (Bậc Thầy Giá Trị)**: Chọn doanh nghiệp có thương hiệu mạnh, lợi thế độc quyền, làm ăn có lãi bền vững nhiều năm (ROE cao).\n"
        "3. 📈 **Peter Lynch (Săn Tăng Trưởng)**: Tìm cổ phiếu có giá còn rẻ so với tốc độ tăng trưởng lợi nhuận (chỉ số PEG hợp lý).\n"
        "4. ⚡ **Mark Minervini (Định Thời Điểm)**: Không mua cổ phiếu đang rơi, chỉ mua khi cổ phiếu đã vào sóng tăng và kỷ luật cắt lỗ -7%.\n"
        "5. 🌊 **Richard Wyckoff (Dấu Chân Cá Mập)**: Nhận diện dòng tiền của tay to, phát hiện các nhịp gom hàng, tránh bị đội lái úp bô.\n"
        "6. 🌐 **Stanley Druckenmiller (Nhìn Vĩ Mô)**: Theo dõi lãi suất của Ngân hàng Nhà nước để khuyên bạn nên giữ tiền mặt hay mua cổ phiếu.\n"
        "7. 📐 **Jim Simons (Toán Học Định Lượng)**: Đo mức độ rung lắc (ATR) để tính xem bạn nên mua bao nhiêu tiền là an toàn nhất.\n"
        "8. ⚖️ **Howard Marks (Bắt Đáy Chu Kỳ)**: Nhắc bạn không fomo hưng phấn ở đỉnh và tìm cơ hội khi thị trường hoảng loạn.\n"
        "9. 🛡️ **Nassim Taleb (Chống Kẹt Sàn)**: Đảm bảo cổ phiếu bạn mua có thanh khoản dồi dào, không sợ bị nhốt sàn trắng bên mua.\n"
        "10. ⚖️ **Quant Auditor (Trọng Tài Giám Sát)**: So sánh ý kiến của 9 chuyên gia trên, nếu có bất đồng quan điểm thì tự động hạ tỷ trọng giải ngân.\n\n"
        "✨ *Bot by Nguyễn Hoàng Trịnh | TikTok: [@nguyenhoangtrinh4](https://www.tiktok.com/@nguyenhoangtrinh4)*\n"
        "☕ *Ủng hộ admin: TPBank `10002654317` (NGUYEN HOANG TRINH)*"
    )
    await message.answer(text, parse_mode=ParseMode.MARKDOWN)

@dp.message(Command("backtest"))
async def cmd_backtest_handler(message: Message):
    parts = message.text.strip().split()
    if len(parts) < 2:
        await message.answer("Vui lòng nhập mã cổ phiếu, ví dụ: `/backtest FPT`")
        return
    symbol = parts[1].upper().strip()
    await run_backtest_for_symbol(message, symbol)

@dp.message(F.text == "📊 Xu Hướng VN-Index")
@dp.message(F.text == "📊 Xu Hướng VN-Index Hôm Nay")
@dp.message(F.text == "Xu Hướng VN-Index")
@dp.message(Command("vnindex"))
@dp.message(Command("thitruong"))
@dp.message(Command("market"))
async def cmd_vnindex_handler(message: Message):
    await handle_vnindex_overview(message)

async def handle_vnindex_overview(message: Message):
    loading_msg = await message.answer(
        "⏳ **Đang triệu tập dữ liệu vĩ mô & phân tích xu hướng VN-Index**...\n*(Đang tính toán các mốc cản MA20/MA50, chỉ báo RSI và thanh khoản dòng tiền)*",
        parse_mode=ParseMode.MARKDOWN
    )
    try:
        loop = asyncio.get_event_loop()
        ov = await loop.run_in_executor(None, fund.get_vnindex_market_overview)

        watchouts_text = "\n".join(f"• {w}" for w in ov["watchouts"])

        msg_text = (
            f"🏛️ **BẢN TIN XU HƯỚNG VN-INDEX & CHIẾN LƯỢC TỔNG QUAN** 🏛️\n"
            f"📅 *Cập nhật ngày: {datetime.now().strftime('%d/%m/%Y %H:%M')}*\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"🚦 **TRẠNG THÁI THỊ TRƯỜNG**: {ov['regime_badge']}\n"
            f"💬 *Đánh giá*: {ov['regime_desc']}\n\n"
            f"📊 **CÁC CHỈ SỐ KỸ THUẬT QUAN TRỌNG**:\n"
            f"• 📈 **Điểm số VN-Index**: `{ov['current_index']:,.0f} điểm`\n"
            f"• 📏 **Đường xu hướng MA**: MA20: `{ov['ma20']:,.0f}` | MA50: `{ov['ma50']:,.0f}` | MA200: `{ov['ma200']:,.0f}`\n"
            f"• ⚡ **Chỉ báo động lượng RSI(14)**: `{ov['rsi']}` *(Vùng {'Quá Bán sâu - dễ có nhịp nảy hồi' if ov['rsi'] < 30 else ('Quá Mua - cẩn trọng đỉnh' if ov['rsi'] > 70 else 'Cân bằng')})*\n"
            f"• 💧 **Khối lượng giao dịch**: `{ov['vol_latest']:,.0f} cp` *(Tỷ lệ: {ov['vol_ratio']}x so với TB 20 phiên)*\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"🛡️ **VÙNG GIÁ TRỌNG YẾU**:\n"
            f"• 🟢 **Hỗ trợ tâm lý / Đáy cứng**: `{ov['support_zone']}`\n"
            f"• 🛑 **Kháng cự cản ngắn hạn**: `{ov['resistance_zone']}`\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"💼 **KẾ HOẠCH TÁC CHIẾN TÀI SẢN (F0 & NĐT)**:\n"
            f"• 💵 **Tỷ trọng an toàn**: `{ov['cash_alloc']}`\n"
            f"• 🎯 **Hành động khuyên dùng**: {ov['recommended_action']}\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"⚠️ **4 ĐIỀU CỰC KỲ CẦN CHÚ Ý**:\n"
            f"{watchouts_text}\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"🛡️ **GÓC NHÌN PHẢN BIỆN (DEVIL'S ADVOCATE)**:\n"
            f"• {ov['devils_note']}\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"✨ *Bot by Nguyễn Hoàng Trịnh | TikTok: [@nguyenhoangtrinh4](https://www.tiktok.com/@nguyenhoangtrinh4) xin 1 follow ạ ❤️*\n"
            f"☕ *Mời admin ly cà phê ủng hộ server: TPBank `10002654317` (NGUYEN HOANG TRINH)*"
        )

        inline_kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(text="☕ Ủng Hộ Tác Giả (TPBank) ❤️", callback_data="donate"),
                    InlineKeyboardButton(text="📱 TikTok @nguyenhoangtrinh4", url="https://www.tiktok.com/@nguyenhoangtrinh4")
                ]
            ]
        )
        await loading_msg.delete()
        await message.answer(msg_text, parse_mode=ParseMode.MARKDOWN, reply_markup=inline_kb)
    except Exception as e:
        logger.error(f"Lỗi phân tích VN-Index: {e}")
        await loading_msg.edit_text(f"❌ Có lỗi khi lấy dữ liệu VN-Index: {str(e)}")

@dp.message(F.text == "🎯 Danh Mục Mua & Né Tránh")
@dp.message(F.text == "Danh Mục Mua & Né Tránh")
@dp.message(Command("danhmuc"))
@dp.message(Command("top"))
@dp.message(Command("watchlist"))
async def cmd_portfolio_handler(message: Message):
    await handle_portfolio_overview(message)

async def handle_portfolio_overview(message: Message):
    loading_msg = await message.answer(
        "⏳ **Đang triệu tập dữ liệu và sàng lọc danh mục từ 10 Siêu AI**...\n*(Đang phân loại cổ phiếu Nên Mua, Cần Theo Dõi và Cảnh Báo Né Tránh)*",
        parse_mode=ParseMode.MARKDOWN
    )
    try:
        loop = asyncio.get_event_loop()
        data = await loop.run_in_executor(None, screener.get_market_portfolios)

        long_term_items = data.get("long_term_list", [])
        trading_items = data.get("trading_list", [])
        avoid_items = data.get("avoid_list", [])

        # 1. Danh mục Tích Sản Dài Hạn
        long_term_text = ""
        for b in long_term_items:
            long_term_text += (
                f"• 🟢 **`{b['symbol']}` ({b['current_price']:,.0f} VNĐ)** — *{b['sector']}*\n"
                f"   └ 💎 *Lợi thế tích sản*: {b['moat_advantage']}\n"
                f"   └ 💵 Vùng gom tích sản: `{b['buy_zone']}`\n"
                f"   └ 🛑 Cắt lỗ kỹ thuật: `{b['stop_loss']}`\n"
                f"   └ 🎯 Mục tiêu 12-24T: `{b['target_price']}` | R:R: `{b['risk_reward']}`\n"
                f"   └ ⏱️ *Chiến lược*: {b['time_horizon']}\n\n"
            )

        # 2. Danh mục Đầu Cơ Lướt Sóng Ngắn Hạn
        trading_text = ""
        for t in trading_items:
            trading_text += (
                f"• ⚡ **`{t['symbol']}` ({t['current_price']:,.0f} VNĐ)** — *{t['sector']}*\n"
                f"   └ 🚀 *Động lực bùng nổ*: {t['catalyst']}\n"
                f"   └ 💵 Vùng mua kéo ngược: `{t['buy_zone']}`\n"
                f"   └ 🚀 Điểm nổ Breakout: `{t['breakout_point']}`\n"
                f"   └ 🛑 Cắt lỗ cứng: `{t['stop_loss']}`\n"
                f"   └ 🎯 Mục tiêu T+: `{t['target_price']}` | R:R: `{t['risk_reward']}`\n"
                f"   └ ⏱️ *Chiến lược*: {t['time_horizon']}\n\n"
            )

        # 3. Danh mục Né Tránh
        avoid_text = ""
        for a in avoid_items:
            avoid_text += (
                f"• 🔴 **`{a['symbol']}` ({a['current_price']:,.0f} VNĐ)** — *{a['sector']}*\n"
                f"   └ ⚠️ *Cảnh báo rủi ro*: {a['reason']}\n\n"
            )

        portfolio_msg = (
            f"🏛️ **BẢNG PHÂN LOẠI DANH MỤC THỊ TRƯỜNG (10 SIÊU AI)** 🏛️\n"
            f"📅 *Cập nhật ngày: {data.get('updated_at', '')}*\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"🟢 **1. DANH MỤC TÍCH SẢN DÀI HẠN (VALUE & ACCUMULATION)**:\n"
            f"*(Doanh nghiệp đầu ngành, Moat lớn, ROE > 20%, nợ thấp, gom định kỳ khi chiết khấu)*\n\n"
            f"{long_term_text}"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"⚡ **2. DANH MỤC ĐẦU CƠ LƯỚT SÓNG NGẮN HẠN (SWING TRADING & MOMENTUM)**:\n"
            f"*(Sóng tăng Giai đoạn 2 Minervini, dòng tiền cá mập Wyckoff, bùng nổ Vol vượt cản)*\n\n"
            f"{trading_text}"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"🔴 **3. DANH MỤC NGUY HIỂM — TUYỆT ĐỐI NÉ TRÁNH (AVOID / BLACKLIST)**:\n"
            f"*(Nợ vay đòn bẩy lớn, áp lực trái phiếu, BCTC nguy hiểm, dòng tiền đầu cơ)*\n\n"
            f"{avoid_text}"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"💼 **NGUYÊN TẮC GIẢI NGÂN SỐNG CÒN CHO NHÀ ĐẦU TƯ (F0)**:\n"
            f"• 1️⃣ **Tích sản dài hạn**: Chia tiền gom đều đặn hàng tháng khi giá về vùng gom chiết khấu, không mua đuổi khi tăng nóng.\n"
            f"• 2️⃣ **Lướt sóng ngắn hạn**: Tuân thủ quy tắc 3 đợt `30% - 30% - 40%`. Chỉ gia tăng khi đợt 1 có lãi và chốt lời dứt khoát tại kháng cự.\n"
            f"• 3️⃣ **Kỷ luật sinh tử**: Đã lướt sóng thì chạm mức cắt lỗ -7% là BÁN NGAY, không bao giờ để biến một lệnh lướt sóng ngắn hạn thành kẹp hàng dài hạn!\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"✨ *Bot by Nguyễn Hoàng Trịnh | TikTok: [@nguyenhoangtrinh4](https://www.tiktok.com/@nguyenhoangtrinh4) xin 1 follow ạ ❤️*\n"
            f"☕ *Mời admin ly cà phê ủng hộ server: TPBank `10002654317` (NGUYEN HOANG TRINH)*"
        )

        inline_kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(text="☕ Ủng Hộ Tác Giả (TPBank) ❤️", callback_data="donate"),
                    InlineKeyboardButton(text="📱 TikTok @nguyenhoangtrinh4", url="https://www.tiktok.com/@nguyenhoangtrinh4")
                ]
            ]
        )
        await loading_msg.delete()
        await message.answer(portfolio_msg, parse_mode=ParseMode.MARKDOWN, reply_markup=inline_kb)
    except Exception as e:
        logger.error(f"Lỗi phân loại danh mục: {e}")
        await loading_msg.edit_text(f"❌ Có lỗi khi sàng lọc danh mục: {str(e)}")

@dp.message(Command("pt"))
@dp.message(F.text)
async def handle_stock_analysis(message: Message):
    raw_text = message.text.strip()
    if raw_text.startswith("/"):
        parts = raw_text.split()
        if len(parts) >= 2:
            query = parts[1].strip()
        else:
            await message.answer("Vui lòng nhập mã cổ phiếu sau lệnh /pt. Ví dụ: `/pt FPT`", parse_mode=ParseMode.MARKDOWN)
            return
    else:
        query = raw_text

    upper_text = query.upper()

    # 1. Nhận diện các lệnh/nút bấm liên quan tới VN-Index & Xu Hướng Thị Trường
    if any(k in upper_text for k in ["VNINDEX", "VN-INDEX", "THỊ TRƯỜNG", "THITRUONG", "VNI", "INDEX", "XU HƯỚNG", "XUHUONG"]):
        await handle_vnindex_overview(message)
        return

    # 2. Nhận diện các lệnh/nút bấm liên quan tới Danh Mục Mua & Né Tránh
    if any(k in upper_text for k in ["DANHMUC", "DANH MỤC", "PORTFOLIO", "WATCHLIST", "TOPMUA", "NÉ TRÁNH", "NETRANH", "TÍCH SẢN", "TICHSAN", "LƯỚT SÓNG", "LUOTSONG"]):
        await handle_portfolio_overview(message)
        return

    # 3. Nhận diện Hướng Dẫn / F0
    if any(k in upper_text for k in ["HƯỚNG DẪN", "HUONG DAN", "HUONGDAN", "CẨM NANG", "CAM NANG", "F0"]):
        await cmd_help(message)
        return

    # 4. Nhận diện 10 Siêu AI
    if any(k in upper_text for k in ["10 SIÊU AI", "10 AI", "CHUYÊN GIA"]):
        await cmd_intro(message)
        return

    # 5. Nhận diện Ủng hộ / Donate
    if any(k in upper_text for k in ["ỦNG HỘ", "UNG HO", "DONATE", "TPBANK"]):
        await cmd_donate_handler(message)
        return

    # 6. Nhận diện TikTok
    if any(k in upper_text for k in ["TIKTOK"]):
        await cmd_tiktok(message)
        return

    # 7. Xử lý mã cổ phiếu: lọc bỏ khoảng trắng và ký tự đặc biệt ($FPT, #SSI -> FPT, SSI)
    symbol = "".join(ch for ch in upper_text if ch.isalnum())

    # Kiểm tra mã hợp lệ (3-5 ký tự chữ cái)
    if not symbol.isalpha() or len(symbol) < 3 or len(symbol) > 5:
        await message.answer(f"Mã '{raw_text}' không đúng định dạng chứng khoán Việt Nam (3-5 chữ cái). Vui lòng thử lại với mã như `FPT`, `HPG`, `SSI`...")
        return

    loading_msg = await message.answer(
        f"⏳ **Đang tải thông tin mã `{symbol}`**...",
        parse_mode=ParseMode.MARKDOWN
    )

    try:
        loop = asyncio.get_event_loop()
        company = await loop.run_in_executor(None, fund.fetcher.get_company_overview, symbol)
        tech = await loop.run_in_executor(None, fund.fetcher.get_technical_analysis, symbol)

        curr_p = tech.get("current_price", 0)
        c_name = company.get("company_name", f"CTCP {symbol}")
        c_ex = company.get("exchange", "HOSE")
        c_ind = company.get("industry", "Chứng khoán / Doanh nghiệp")

        intro_msg = (
            f"🏛️ **HỘI ĐỒNG 10 SIÊU AI — PHÂN TÍCH MÃ: `{symbol}`** 🏛️\n"
            f"🏢 **{c_name}** (Sàn: **{c_ex}**)\n"
            f"💵 **Giá hiện tại**: `{curr_p:,.0f} VNĐ` | Nhóm ngành: **{c_ind}**\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"👉 **Vui lòng chọn VỊ THẾ HIỆN TẠI của bạn đối với `{symbol}`**:\n"
            f"*(Hội đồng sẽ đưa ra khuyến nghị kỹ thuật & kế hoạch tác chiến chính xác nhất)*"
        )

        await loading_msg.delete()
        await message.answer(
            intro_msg,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=get_position_selection_keyboard(symbol)
        )
    except Exception as e:
        logger.error(f"Lỗi khởi tạo {symbol}: {e}")
        try:
            await loading_msg.delete()
        except Exception:
            pass
        await message.answer(
            f"🏛️ **HỘI ĐỒNG 10 SIÊU AI — PHÂN TÍCH MÃ: `{symbol}`** 🏛️\n"
            f"👉 **Vui lòng chọn VỊ THẾ HIỆN TẠI của bạn để bắt đầu:**",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=get_position_selection_keyboard(symbol)
        )

@dp.callback_query(F.data.startswith("buyer_") | F.data.startswith("pos_buyer_"))
async def cb_buyer_step2(callback: CallbackQuery):
    try:
        await callback.answer()
    except Exception:
        pass
    parts = callback.data.split("_")
    symbol = parts[-1].upper().strip()

    text = (
        f"🏛️ **HỘI ĐỒNG 10 SIÊU AI — MÃ: `{symbol}`** 🏛️\n"
        f"✅ Vị thế bạn chọn: 🟢 **Tôi Muốn Mua Mới**\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"👉 **BƯỚC 2/2: Bạn muốn ĐẦU TƯ DÀI HẠN hay LƯỚT SÓNG NGẮN HẠN?**\n\n"
        f"• 💎 **Đầu Tư Tích Sản Dài Hạn**: Tập trung vào lợi thế cạnh tranh (Moat), định giá P/E & P/B, mua gom tích sản theo tháng/quý và đồng hành 2 - 5 năm.\n"
        f"• ⚡ **Lướt Sóng Ngắn Hạn (T+)**: Bắt nhịp sóng dòng tiền cá mập, điểm bùng nổ Breakout, tuân thủ cắt lỗ -7% và chốt lời kỹ thuật ngắn hạn T+2.5.\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"*(Vui lòng bấm chọn 1 trong 2 mục tiêu bên dưới để nhận khuyến nghị)*"
    )
    kb = get_style_selection_keyboard(symbol, position="buyer")
    try:
        await callback.message.edit_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb)
    except Exception:
        await callback.message.answer(text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb)

@dp.callback_query(F.data.startswith("holder_") | F.data.startswith("pos_holder_"))
async def cb_holder_step2(callback: CallbackQuery):
    try:
        await callback.answer()
    except Exception:
        pass
    parts = callback.data.split("_")
    symbol = parts[-1].upper().strip()

    text = (
        f"🏛️ **HỘI ĐỒNG 10 SIÊU AI — MÃ: `{symbol}`** 🏛️\n"
        f"✅ Vị thế bạn chọn: 🔵 **Tôi Đang Cầm Hàng**\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"👉 **BƯỚC 2/2: Bạn muốn ĐẦU TƯ DÀI HẠN hay LƯỚT SÓNG NGẮN HẠN?**\n\n"
        f"• 💎 **Đầu Tư Tích Sản Dài Hạn**: Thẩm định lại nội tại doanh nghiệp, kế hoạch tiếp tục gom giá sàn hạ giá vốn hay tái cơ cấu sang mã Bluechip.\n"
        f"• ⚡ **Lướt Sóng Ngắn Hạn (T+)**: Kỹ thuật lướt T0 hạ giá vốn trên hàng có sẵn, các mốc cản MA20/MA50 canh bán và kích hoạt chặn lãi Trailing Stop.\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"*(Vui lòng bấm chọn 1 trong 2 mục tiêu bên dưới để nhận khuyến nghị)*"
    )
    kb = get_style_selection_keyboard(symbol, position="holder")
    try:
        await callback.message.edit_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb)
    except Exception:
        await callback.message.answer(text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb)

@dp.callback_query(F.data.startswith("select_pos_"))
async def cb_select_pos_back(callback: CallbackQuery):
    try:
        await callback.answer()
    except Exception:
        pass
    parts = callback.data.split("_")
    symbol = parts[-1].upper().strip()

    text = (
        f"🏛️ **HỘI ĐỒNG 10 SIÊU AI — PHÂN TÍCH MÃ: `{symbol}`** 🏛️\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"👉 **Vui lòng chọn VỊ THẾ HIỆN TẠI của bạn đối với `{symbol}`**:\n"
        f"*(Hội đồng sẽ đưa ra khuyến nghị kỹ thuật & kế hoạch tác chiến chính xác nhất)*"
    )
    kb = get_position_selection_keyboard(symbol)
    try:
        await callback.message.edit_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb)
    except Exception:
        await callback.message.answer(text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb)

@dp.callback_query(F.data.startswith("plan_"))
async def cb_investment_plan(callback: CallbackQuery):
    try:
        await callback.answer()
    except Exception:
        pass

    # data format: plan_{position}_{style}_{symbol}
    parts = callback.data.split("_")
    if len(parts) < 4:
        return
    position = parts[1]   # "buyer" or "holder"
    style = parts[2]      # "long" or "short"
    symbol = parts[3].upper().strip()

    pos_title = "MUA MỚI" if position == "buyer" else "NGƯỜI CẦM HÀNG"
    style_title = "TÍCH SẢN DÀI HẠN" if style == "long" else "LƯỚT SÓNG NGẮN HẠN (T+)"

    msg_wait = await callback.message.answer(
        f"⏳ **Đang trích xuất kế hoạch {pos_title} — {style_title} cho mã `{symbol}`**...\n*(Hội đồng 10 Siêu AI đang phân tích dữ liệu BCTC, kỹ thuật và quản trị vốn)*",
        parse_mode=ParseMode.MARKDOWN
    )

    try:
        loop = asyncio.get_event_loop()
        res = await loop.run_in_executor(None, fund.run_investment_committee, symbol)
        decision = res.get("decision", {})
        company = res.get("company", {})
        tech = res.get("tech", {})
        financials = res.get("financials", {})
        ai = res.get("agent_details", {})
        burry = ai.get("burry", {})
        buffett = ai.get("buffett", {})
        lynch = ai.get("lynch", {})

        current_price = tech.get("current_price", 0)
        c_name = company.get("company_name", symbol)
        ma20 = tech.get("ma20", current_price)
        ma50 = tech.get("ma50", current_price)
        ma200 = tech.get("ma200", current_price)
        rsi = tech.get("rsi_14", 50.0)
        support_s1 = tech.get("support_s1", current_price * 0.95)
        resistance_r1 = tech.get("resistance_r1", current_price * 1.05)

        # Chỉ số cơ bản & định giá
        pe = financials.get("pe", 15.0)
        pb = financials.get("pb", 1.8)
        peg = financials.get("peg_ratio", 1.2)
        de = financials.get("debt_to_equity", 0.6)
        cfo_history = financials.get("cfo_history", [1000])
        cfo_latest = cfo_history[0] if cfo_history else 0
        roe_history = financials.get("roe_history", [15.0])
        avg_roe = sum(roe_history) / len(roe_history) if roe_history else 15.0
        z_score = financials.get("altman_z_score", 3.0)

        # Thông số kỹ thuật từ CIO
        action_val = decision.get("final_action", "")
        pos_pct = decision.get("position_size_pct", 0)
        buy_zone = decision.get("buy_zone", "N/A")
        buy_ta_reason = decision.get("buy_ta_reason", "Kiểm định hỗ trợ động MA20 & Swing Low")
        breakout = decision.get("breakout_point", "N/A")
        stop_loss = decision.get("stop_loss", "N/A")
        stop_loss_ta_reason = decision.get("stop_loss_ta_reason", "Thủng đáy ngắn hạn, cắt lỗ bảo toàn vốn")
        target_price = decision.get("target_price", "N/A")
        target_ta_reason = decision.get("target_ta_reason", "Kháng cự kỹ thuật Bollinger / Đỉnh cũ")
        trailing_stop_rule = decision.get("trailing_stop_rule", "Nâng dần theo MA20")
        rr = decision.get("risk_reward", "1 : 2.5")

        is_buyable = ("MUA" in action_val and "CHƯA" not in action_val and "THEO DÕI" not in action_val and not burry.get("veto_exercised"))
        is_long_worthy = (avg_roe >= 15.0 and de <= 0.85 and cfo_latest > 0 and z_score >= 2.5 and not burry.get("veto_exercised"))

        # 4 KỊCH BẢN CHI TIẾT
        if position == "buyer" and style == "long":
            # KỊCH BẢN 1: MUA MỚI + ĐẦU TƯ TÍCH SẢN DÀI HẠN
            if burry.get("veto_exercised"):
                badge = "🛑 **TUYỆT ĐỐI KHÔNG TÍCH SẢN — NGUY CƠ GIAN LẬN / PHÁ SẢN**"
                badge_desc = f"Michael Burry kích hoạt VETO: {burry.get('veto_reason')}. Cổ phiếu này không có con hào kinh tế, tích sản rất dễ mất trắng!"
            elif is_long_worthy:
                badge = "🟢 **ĐẠT CHUẨN VÀNG TÍCH SẢN DÀI HẠN (2 - 5 NĂM)**"
                badge_desc = "Doanh nghiệp đầu ngành, lợi thế độc quyền lớn (Moat), ROE cao bền vững, dòng tiền kinh doanh CFO dương và cơ cấu nợ cực kỳ an toàn."
            else:
                badge = "🟡 **TÍNH CHU KỲ HOẶC RỦI RO TRUNG BÌNH — CHỈ GOM KHI CHIẾT KHẤU SÂU**"
                badge_desc = "Cổ phiếu có tính chu kỳ ngành cao hoặc định giá chưa đủ rẻ. Cần kiên nhẫn chờ những đợt thị trường sập sâu mới gom tích sản."

            accum_low = min(ma200 * 0.92, current_price * 0.92)
            accum_high = max(ma200 * 1.02, current_price * 1.0)
            accum_zone = f"{accum_low:,.0f} - {accum_high:,.0f} VNĐ"

            plan_text = (
                f"💎 **CHIẾN LƯỢC MUA MỚI TÍCH SẢN DÀI HẠN: `{symbol}`** 💎\n"
                f"🏢 **{c_name}** | Giá hiện tại: `{current_price:,.0f} VNĐ`\n"
                f"━━━━━━━━━━━━━━━━━━━\n"
                f"🚦 **ĐÁNH GIÁ CHUẨN TÍCH SẢN**: {badge}\n"
                f"💬 *Nhận định*: {badge_desc}\n\n"
                f"📊 **BỘ CHỈ SỐ THẨM ĐỊNH NỘI TẠI DOANH NGHIỆP**:\n"
                f"• 🦉 **Con hào kinh tế (Warren Buffett)**: `{buffett.get('moat_type', 'Thương hiệu đầu ngành')}`\n"
                f"• 📈 **Hiệu quả sinh lời ROE bình quân**: `{avg_roe:.1f}%/năm` *(Chuẩn Buffett $\\ge 18\%$)*\n"
                f"• 💵 **Định giá P/E**: `{pe:.1f}x` | **P/B**: `{pb:.1f}x` | **PEG**: `{peg:.2f}` *(Peter Lynch)*\n"
                f"• 🛡️ **Dòng tiền kinh doanh (CFO)**: `{cfo_latest:,.0f} tỷ` *(Tiền tươi thóc thật từ bán hàng)*\n"
                f"• ⚖️ **Tỷ lệ nợ vay / Vốn CSH (D/E)**: `{de:.2f}x` *(Ngưỡng an toàn < 0.8x)*\n"
                f"• 🚨 **Sức khỏe phá sản (Altman Z-Score)**: `{z_score:.2f}` *({ 'An toàn tài chính' if z_score >= 2.9 else 'Cần lưu ý' })*\n"
                f"━━━━━━━━━━━━━━━━━━━\n"
                f"🎯 **VÙNG GIÁ GOM TÍCH SẢN AN TOÀN DÀI HẠN**:\n"
                f"• 🟢 **Vùng gom tối ưu (Accumulation Zone)**: `{accum_zone}`\n"
                f"   └ 📐 *Căn cứ PTKT & Định giá*: Quanh đường xu hướng dài hạn MA200 (`{ma200:,.0f} VNĐ`) hoặc khi thị trường hoảng loạn chiết khấu sâu.\n"
                f"• ⏳ **Tầm nhìn đầu tư**: **2 - 5 năm** *(Bỏ qua hoàn toàn rung lắc vài phiên T+2.5)*\n"
                f"• 💰 **Mục tiêu kỳ vọng**: Tăng trưởng kép **+20% ~ +35%/năm** + Nhận cổ tức tiền mặt đều đặn.\n"
                f"━━━━━━━━━━━━━━━━━━━\n"
                f"💼 **QUY TẮC ĐI VỐN TÍCH SẢN CHO BẠN (F0)**:\n"
                f"1. **Chiến lược chia vốn DCA**: Trích 10% - 20% thu nhập hàng tháng/quý mua gom đều đặn khi giá nằm trong vùng gom an toàn.\n"
                f"2. **TUYỆT ĐỐI KHÔNG DÙNG MARGIN**: Đầu tư dài hạn mà dùng Margin gặp phiên sập giải chấp sẽ bị cháy tài khoản trước khi kịp hái quả ngọt!\n"
                f"3. **Tái đầu tư cổ tức**: Dùng toàn bộ cổ tức tiền mặt được chia để mua tiếp cổ phiếu, kích hoạt sức mạnh kỳ diệu của **Lãi Kép**.\n"
                f"4. **Kỷ luật sinh tử**: CHỈ BÁN KHI nội tại doanh nghiệp bị phá vỡ (ban lãnh đạo gian lận BCTC, mất vị thế độc quyền), KHÔNG bao giờ bán tháo chỉ vì giá giảm ngắn hạn.\n"
                f"━━━━━━━━━━━━━━━━━━━\n"
                f"✨ *Bot by Nguyễn Hoàng Trịnh | TikTok: [@nguyenhoangtrinh4](https://www.tiktok.com/@nguyenhoangtrinh4) xin 1 follow ạ ❤️*\n"
                f"☕ *Ủng hộ admin: TPBank `10002654317` (NGUYEN HOANG TRINH)*"
            )

        elif position == "buyer" and style == "short":
            # KỊCH BẢN 2: MUA MỚI + LƯỚT SÓNG NGẮN HẠN (T+)
            if is_buyable:
                status_badge = "🟢 **ĐƯỢC PHÉP MUA MỚI LƯỚT SÓNG (GIẢI NGÂN TỪNG PHẦN)**"
                status_desc = "Cổ phiếu đạt chuẩn chất lượng tài chính, dòng tiền cá mập đang ủng hộ và xu hướng giá thuận lợi."
            elif burry.get("veto_exercised"):
                status_badge = "🛑 **TUYỆT ĐỐI KHÔNG MUA — CẢNH BÁO NGUY HIỂM**"
                status_desc = "Michael Burry phát hiện rủi ro BCTC hoặc nợ quá cao, không bắt dao rơi!"
            else:
                status_badge = "🟡 **CHƯA NÊN MUA MỚI NGAY — NÊN KIÊN NHẪN QUAN SÁT**"
                status_desc = f"Giá đang dưới MA50 ({ma50:,.0f} VNĐ) hoặc đang trong nhịp chỉnh ngắn hạn. Mua đuổi rủi ro dính bẫy T+2.5 rất cao!"

            plan_text = (
                f"⚡ **KẾ HOẠCH TÁC CHIẾN LƯỚT SÓNG NGẮN HẠN (T+): `{symbol}`** ⚡\n"
                f"🏢 **{c_name}** | Giá hiện tại: `{current_price:,.0f} VNĐ`\n"
                f"━━━━━━━━━━━━━━━━━━━\n"
                f"🚦 **KHUYẾN NGHỊ LƯỚT SÓNG**: {status_badge}\n"
                f"💬 *Đánh giá*: {status_desc}\n\n"
                f"🎯 **BỘ 3 THÔNG SỐ KỸ THUẬT: GIÁ MUA - CẮT LỖ - CHỐT LỜI**:\n"
                f"• 🟢 **Vùng Mua Kỹ Thuật (Buy Zone)**: `{buy_zone}`\n"
                f"   └ 📐 *Căn cứ PTKT*: {buy_ta_reason}\n"
                f"• 🚀 **Điểm Kích Hoạt Breakout**: `{breakout}`\n"
                f"• 🛑 **Ngưỡng Cắt Lỗ Kỹ Thuật (Stop Loss)**: `{stop_loss}`\n"
                f"   └ 🛡️ *Căn cứ PTKT*: {stop_loss_ta_reason}\n"
                f"• 💰 **Mục Tiêu Chốt Lời Kỹ Thuật (Take Profit)**: `{target_price}`\n"
                f"   └ 🎯 *Căn cứ PTKT*: {target_ta_reason}\n"
                f"• 📈 **Chiến Lược Chặn Lãi (Trailing Stop)**: {trailing_stop_rule}\n"
                f"• ⚖️ **Tỷ Lệ Risk / Reward (R:R)**: `{rr}`\n"
                f"• 💼 **Tỷ trọng phân bổ đề xuất**: `{pos_pct}% NAV` *(Tối đa {pos_pct}% tài khoản)*\n"
                f"━━━━━━━━━━━━━━━━━━━\n"
                f"🎯 **QUY TRÌNH 3 BƯỚC GIẢI NGÂN SỐNG CÒN CHO BẠN (F0)**:\n"
                f"• **Bước 1 (Thăm dò 30% vị thế)**: Chỉ giải ngân 30% vốn dự kiến trong vùng `{buy_zone}` khi cổ phiếu có nến rút chân giữ vững hỗ trợ. 🛑 *Tuyệt đối KHÔNG mua đuổi khi giá đã tăng trên +3% trong phiên!*\n"
                f"• **Bước 2 (Gia tăng 30% vị thế)**: Chờ đúng hàng đợt 1 về tài khoản (T+2.5) và **đang có lãi** mới được mua thêm đợt 2! Nếu đợt 1 bị lỗ $\\rightarrow$ CẤM tuyệt đối trung bình giá xuống!\n"
                f"• **Bước 3 (Đủ hàng 40% vị thế)**: Giải ngân nốt 40% khi giá vượt dứt khoát mốc `{breakout}` kèm khối lượng bùng nổ vượt 1.5 lần trung bình 20 phiên.\n"
                f"━━━━━━━━━━━━━━━━━━━\n"
                f"⚠️ **LỜI NHẮC TRÁNH BẪY T+2.5**: Nếu cổ phiếu chưa tạo mô hình 2 đáy (W) hoặc chưa vượt lại MA50, các phiên tăng mạnh chỉ là nhịp hồi kỹ thuật (Dead-cat bounce) để xả hàng. Người mua mới tuyệt đối kiên nhẫn chờ nhịp test lại thành công mới vào hàng!\n"
                f"━━━━━━━━━━━━━━━━━━━\n"
                f"✨ *Bot by Nguyễn Hoàng Trịnh | TikTok: [@nguyenhoangtrinh4](https://www.tiktok.com/@nguyenhoangtrinh4) xin 1 follow ạ ❤️*\n"
                f"☕ *Ủng hộ admin: TPBank `10002654317` (NGUYEN HOANG TRINH)*"
            )

        elif position == "holder" and style == "long":
            # KỊCH BẢN 3: ĐANG CẦM HÀNG + TỔ CHỨC LẠI DANH MỤC TÍCH SẢN
            if burry.get("veto_exercised"):
                badge = "🔴 **CẢNH BÁO: CỔ PHIẾU NGUY CƠ CAO — KHÔNG NÊN ÔM LÌ DÀI HẠN!**"
                badge_desc = f"Michael Burry cảnh báo: {burry.get('veto_reason')}. Doanh nghiệp có dấu hiệu xào nấu BCTC hoặc nợ xấu. Ôm dài hạn mã này cực kỳ rủi ro, nên canh nhịp hồi kỹ thuật để cơ cấu chuyển vốn sang Bluechip cơ bản!"
            elif is_long_worthy:
                badge = "🟢 **DOANH NGHIỆP CƠ BẢN XUẤT SẮC — AN TÂM NẮM GIỮ DÀI HẠN**"
                badge_desc = f"{c_name} có ROE ({avg_roe:.1f}%) cao và dòng tiền kinh doanh CFO dương bền vững. Biến động ngắn hạn chỉ là nhiễu động tâm lý đám đông, tiếp tục kiên định đồng hành cùng doanh nghiệp!"
            else:
                badge = "🟡 **DOANH NGHIỆP CHU KỲ — CẦN QUẢN TRỊ TỶ TRỌNG VỪA PHẢI**"
                badge_desc = f"{c_name} có tính chu kỳ hoặc rủi ro nợ vay cần theo dõi. Nên duy trì tỷ trọng vừa phải trong danh mục tổng (dưới 20% NAV), không all-in."

            plan_text = (
                f"💎 **CHIẾN LƯỢC TỔ CHỨC LẠI DANH MỤC TÍCH SẢN: `{symbol}`** 💎\n"
                f"🏢 **{c_name}** | Giá hiện tại: `{current_price:,.0f} VNĐ`\n"
                f"━━━━━━━━━━━━━━━━━━━\n"
                f"🚦 **THẨM ĐỊNH NỘI TẠI DÀI HẠN**: {badge}\n"
                f"💬 *Đánh giá cốt lõi*: {badge_desc}\n\n"
                f"🛡️ **KẾ HOẠCH HÀNH ĐỘNG DÀI HẠN CỤ THỂ CHO BẠN**:\n"
                f"• 🟢 **NẾU BẠN ĐANG CÓ LÃI (Vị thế mua tốt)**:\n"
                f"   └ **Tiếp tục nắm giữ**: Không bị lung lay bởi tin đồn chim lợn hay các phiên rung lắc -2% ~ -3%.\n"
                f"   └ **Mốc bảo vệ vốn dài hạn**: Đặt ngưỡng dừng lỗ mềm bám theo đường MA200 (`{ma200:,.0f} VNĐ`). Chừng nào giá còn trên MA200 thì xu hướng dài hạn vẫn an toàn.\n\n"
                f"• 🔴 **NẾU BẠN ĐANG TẠM LỖ (Mua giá cao)**:\n"
                f"   └ {'**Cơ hội vàng mua gom thêm**: Vì doanh nghiệp cơ bản rất tốt, các nhịp đạp hoảng loạn (RSI < 30 hoặc giảm sâu về MA200 ' + f'{ma200:,.0f} đ) chính là cơ hội dùng tiền nhàn rỗi gom thêm hạ giá vốn bình quân!' if is_long_worthy else '**Cân nhắc cơ cấu dứt khoát**: Doanh nghiệp nội tại yếu, không nên gồng lỗ tích sản. Canh các nhịp kéo nảy xanh hồi phục kỹ thuật để bán hạ tỷ trọng, dồn vốn sang các mã đầu ngành như FPT, HPG, VNM, TCB...'}\n\n"
                f"• ⚖️ **Kỷ luật quản trị rủi ro Nassim Taleb**:\n"
                f"   └ Giữ tỷ lệ tiền mặt dự phòng tối thiểu **20% - 30% NAV** để luôn có đường lui và sẵn sàng săn hàng giá rẻ khi thị trường xảy ra biến cố Thiên Nga Đen.\n"
                f"━━━━━━━━━━━━━━━━━━━\n"
                f"✨ *Bot by Nguyễn Hoàng Trịnh | TikTok: [@nguyenhoangtrinh4](https://www.tiktok.com/@nguyenhoangtrinh4) xin 1 follow ạ ❤️*\n"
                f"☕ *Ủng hộ admin: TPBank `10002654317` (NGUYEN HOANG TRINH)*"
            )

        else:
            # KỊCH BẢN 4: ĐANG CẦM HÀNG + LƯỚT SÓNG NGẮN HẠN (T+)
            plan_text = (
                f"⚡ **CHIẾN LƯỢC XỬ LÝ HÀNG CÓ SẴN (LƯỚT SÓNG & BẢO TOÀN VỐN): `{symbol}`** ⚡\n"
                f"🏢 **{c_name}** | Giá hiện tại: `{current_price:,.0f} VNĐ`\n"
                f"📏 Cản & Hỗ trợ kỹ thuật: MA20: `{ma20:,.0f}` | MA50: `{ma50:,.0f}` | Hỗ trợ S1: `{support_s1:,.0f}` | Kháng cự R1: `{resistance_r1:,.0f}`\n"
                f"━━━━━━━━━━━━━━━━━━━\n"
                f"🟢 **KỊCH BẢN 1: NẾU BẠN ĐANG CÓ LÃI (VỊ THẾ TỐT)**:\n"
                f"• 🛡️ **Kích hoạt Chặn Lãi (Trailing Stop)**: {trailing_stop_rule}\n"
                f"• 🎯 **Kế hoạch chốt lời 2 chặng theo PTKT**:\n"
                f"   └ **Chặng 1 (TP1)**: Bán chủ động 50% vị thế khi chạm `{target_price.split('|')[0] if '|' in target_price else target_price}`. *(Căn cứ: {target_ta_reason})*\n"
                f"   └ **Chặng 2 (TP2)**: Giữ 50% còn lại gồng theo sóng lớn, bám sát đường MA20 ({ma20:,.0f} đ) cho đến khi gãy MA20 mới bán hết.\n"
                f"━━━━━━━━━━━━━━━━━━━\n"
                f"🔴 **KỊCH BẢN 2: NẾU BẠN ĐANG BỊ KẸP HÀNG / LỖ GIÁ CAO**:\n"
                f"• ⚠️ **Nhận định thực tế**: Trong nhịp hồi kỹ thuật của cổ phiếu đang gãy sóng, ĐÂY LÀ CƠ HỘI ĐỂ CƠ CẤU, không phải để mua gom ôm lì!\n"
                f"• ⚡ **Chiêu thức lướt T0 hạ giá vốn (Chỉ dùng trên hàng có sẵn)**:\n"
                f"   └ Vào phiên sáng, khi thị trường có nhịp đạp đỏ sâu hoảng loạn về sát hỗ trợ ({support_s1:,.0f} đ), dùng tiền mặt mua thêm 20% - 30% lượng cổ phiếu đang có sẵn.\n"
                f"   └ Trong phiên chiều, khi có nhịp kéo nẩy xanh $+3\% \\sim +4\%$, **BÁN NGAY LẬP TỨC** lượng hàng vừa mua (lấy từ số cổ phiếu có sẵn trong kho). Số lượng cổ phiếu không đổi nhưng bạn kéo tụt giá vốn bình quân xuống đáng kể!\n"
                f"• 🛑 **Canh bán hạ tỷ trọng tại các mốc cản kỹ thuật**:\n"
                f"   └ Cản gần nhất MA20: `{ma20:,.0f} VNĐ` (hoặc R1: `{resistance_r1:,.0f} VNĐ`)\n"
                f"   └ Cản trung hạn MA50: `{ma50:,.0f} VNĐ`\n"
                f"   👉 Khi giá chạm vào các vùng cản này mà hụt hơi thanh khoản, chủ động bán bớt 30% - 50% để thu tiền về phòng vệ.\n"
                f"• 🚨 **Kỷ luật sinh tử**: Nếu giá rơi thủng đáy cứng `{stop_loss}` ({stop_loss_ta_reason}) $\\rightarrow$ Phải kiên quyết cắt lỗ, tuyệt đối không gồng để khoản lỗ phình to từ -7% lên -30%!\n"
                f"━━━━━━━━━━━━━━━━━━━\n"
                f"✨ *Bot by Nguyễn Hoàng Trịnh | TikTok: [@nguyenhoangtrinh4](https://www.tiktok.com/@nguyenhoangtrinh4) xin 1 follow ạ ❤️*\n"
                f"☕ *Ủng hộ admin: TPBank `10002654317` (NGUYEN HOANG TRINH)*"
            )

        await msg_wait.delete()
        try:
            await callback.message.answer(
                plan_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=get_action_inline_keyboard(symbol, position=position, style=style)
            )
        except Exception:
            await callback.message.answer(
                plan_text,
                reply_markup=get_action_inline_keyboard(symbol, position=position, style=style)
            )
    except Exception as e:
        logger.error(f"Lỗi kế hoạch {position}-{style} cho {symbol}: {e}")
        await msg_wait.edit_text(f"❌ Có lỗi khi trích xuất kế hoạch: {str(e)}")

@dp.callback_query(F.data.startswith("audit_") | F.data.startswith("debate_"))
async def cb_audit(callback: CallbackQuery):
    symbol = callback.data.split("_")[1]
    try:
        await callback.answer()
    except Exception:
        pass
    
    msg_wait = await callback.message.answer(f"⏳ Đang lấy ý kiến đánh giá từ 10 Chuyên Gia AI cho mã `{symbol}`...")
    try:
        loop = asyncio.get_event_loop()
        res = await loop.run_in_executor(None, fund.run_investment_committee, symbol)
        ai = res.get("agent_details", {})
        auditor = res.get("auditor", {})
        company = res.get("company", {})
        decision = res.get("decision", {})
        tech = res.get("tech", {})

        burry = ai.get("burry", {})
        buffett = ai.get("buffett", {})
        lynch = ai.get("lynch", {})
        minervini = ai.get("minervini", {})
        wyckoff = ai.get("wyckoff", {})
        druckenmiller = ai.get("druckenmiller", {})
        simons = ai.get("simons", {})
        marks = ai.get("marks", {})
        taleb = ai.get("taleb", {})

        score_val = decision.get("composite_score", 5.0)
        action_val = decision.get("final_action", "")
        pos_val = decision.get("position_size_pct", 0)

        # 🎯 Tổng hợp Lời Khuyên Tối Hậu của Hội Đồng 10 Chuyên Gia
        if burry.get("veto_exercised"):
            advice_badge = "🛑 **TUYỆT ĐỐI NÉ TRÁNH — KHÔNG BẮT DAO RƠI!**"
            advice_body = (
                "Chuyên gia Michael Burry phát hiện rủi ro BCTC nguy hiểm hoặc nợ vay vượt trần kiểm soát.\n"
                "👉 **Lời khuyên**: Giữ chặt tiền mặt mồ hôi nước mắt, tuyệt đối không bắt đáy các cổ phiếu đang vướng nghi vấn tài chính!"
            )
        elif "MUA" in action_val and "CHƯA" not in action_val and "THEO DÕI" not in action_val:
            advice_badge = "🟢 **HỘI ĐỒNG ĐỒNG THUẬN PHÊ DUYỆT GIẢI NGÂN (MUA TỪNG PHẦN)!**"
            advice_body = (
                f"Cổ phiếu hội tụ đầy đủ giá trị kinh doanh (Buffett & Lynch ủng hộ) và dòng tiền vào đẩy giá (Minervini & Wyckoff phê chuẩn).\n"
                f"👉 **Kế hoạch hành động**:\n"
                f"• Phân bổ tối đa: `{pos_val}% NAV` *(Bắt buộc chia 3 đợt: 30% - 30% - 40%)*.\n"
                f"• Vùng mua gom chiết khấu: `{decision.get('buy_zone')}`\n"
                f"• Ngưỡng cắt lỗ cứng (-7%): `{decision.get('stop_loss')}` *(Thủng là bán, không gồng lỗ)*\n"
                f"• Mục tiêu chốt lời kỳ vọng: `{decision.get('target_price')}` *(Gồng lãi theo sóng lớn)*"
            )
        elif "CHƯA" in action_val or "THEO DÕI" in action_val or score_val >= 5.0:
            advice_badge = "🟡 **ĐỨNG NGOÀI QUAN SÁT — CHƯA NÊN MUA NGAY (KIÊN NHẪN CHỜ ĐÁY)!**"
            advice_body = (
                f"Doanh nghiệp có nền tảng cơ bản khá tốt, nhưng Minervini và Quant cảnh báo giá đang dưới MA50 ({tech.get('ma50', 0):,.0f} VNĐ), chưa vào sóng tăng và rủi ro T+2.5 còn cao.\n"
                f"👉 **Lời khuyên cho bạn**:\n"
                f"• **Nếu đang kẹp hàng giá cao**: Canh các nhịp nẩy hồi chạm cản MA20 ({tech.get('ma20', 0):,.0f} VNĐ) để hạ bớt tỷ trọng hoặc lướt T0 trên lượng hàng có sẵn để kéo giá vốn xuống.\n"
                f"• **Nếu đang cầm tiền mặt**: Tuyệt đối KHÔNG mua đuổi các phiên xanh tím! Kiên nhẫn chờ cổ phiếu tích lũy tạo đáy 2 (W) vượt lại MA50 kèm Vol lớn mới giải ngân an toàn!"
            )
        else:
            advice_badge = "🔴 **ĐỨNG NGOÀI HOÀN TOÀN — BẢO VỆ VỐN LÀ ƯU TIÊN SỐ 1!**"
            advice_body = (
                "Cổ phiếu đang chịu áp lực bán tháo áp đảo, chưa có dòng tiền cá mập đỡ giá.\n"
                "👉 **Lời khuyên**: Giữ 100% tiền mặt. Tuyệt đối không trung bình giá xuống kẻo kẹt vốn dài hạn!"
            )

        audit_text = (
            f"🧠 **10 CHUYÊN GIA AI ĐÁNH GIÁ MÃ: `{symbol}`**\n"
            f"🏢 **{company.get('company_name', symbol)}** ({company.get('exchange', 'HOSE')})\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"1. 🕵️ **Michael Burry (Soi BCTC & Gian Lận)**: {burry.get('safety_status', 'N/A')}\n"
            f"   └ Độ an toàn nợ: `{burry.get('altman_z_score', 'N/A')}` | Phủ quyết: `{'KÍCH HOẠT VETO (Cấm mua)' if burry.get('veto_exercised') else 'An Toàn'}`\n"
            f"2. 🦉 **Warren Buffett (Thương Hiệu & Uy Tín)**: `{buffett.get('buffett_score', 0)}/10`\n"
            f"   └ Lợi thế cạnh tranh: {buffett.get('moat_level', 'N/A')} | Lãi ròng ROE 3 năm: `{buffett.get('avg_roe', 'N/A')}%`\n"
            f"3. 📈 **Peter Lynch (Săn Cổ Phiếu Tăng Trưởng)**: `{lynch.get('lynch_score', 0)}/10`\n"
            f"   └ Nhóm cổ phiếu: {lynch.get('category', 'N/A')} | Định giá PEG: `{lynch.get('peg_ratio', 'N/A')}x`\n"
            f"4. ⚡ **Mark Minervini (Định Thời Điểm Vào Hàng)**: `{minervini.get('timing_score', 0)}/10`\n"
            f"   └ Chuẩn sóng tăng: `{minervini.get('trend_template_passed', 0)}/8 tiêu chí` | Đang trong sóng tăng: `{'Có' if minervini.get('is_uptrend') else 'Chưa'}`\n"
            f"5. 🌊 **Richard Wyckoff (Dòng Tiền Cá Mập)**: `{wyckoff.get('whale_score', 0)}/10`\n"
            f"   └ Hành động của tay to: `{wyckoff.get('phase', 'N/A')}`\n"
            f"6. 🌐 **Stanley Druckenmiller (Vĩ Mô Tiền Tệ)**: `{druckenmiller.get('macro_score', 0)}/10`\n"
            f"   └ Môi trường lãi suất: {druckenmiller.get('monetary_climate', 'N/A')}\n"
            f"7. 📐 **Jim Simons (Toán Học Định Lượng)**: `{simons.get('quant_score', 0)}/10`\n"
            f"   └ Rung lắc ngày: `{simons.get('atr_pct', 'N/A')}%` | Xác suất thắng thế: `{simons.get('win_probability_pct', 'N/A')}%`\n"
            f"8. ⚖️ **Howard Marks (Bắt Đáy Chu Kỳ)**: `{marks.get('marks_score', 0)}/10`\n"
            f"   └ Tâm lý thị trường: {marks.get('cycle_stage', 'N/A')}\n"
            f"9. 🛡️ **Nassim Taleb (Chống Kẹt Sàn & Thanh Khoản)**: `{taleb.get('taleb_score', 0)}/10`\n"
            f"   └ Mức độ an toàn thoát hàng: {taleb.get('liquidity_status', 'N/A')}\n"
            f"10. ⚖️ **Quant Auditor (Trọng Tài Giám Sát)**: {auditor.get('consensus_status', 'N/A')}\n"
            f"   └ Độ lệch ý kiến: `{auditor.get('score_std_dev', 0)}` | {auditor.get('consensus_status', 'N/A')}\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"🎯 **TỔNG KẾT & LỜI KHUYÊN TỐI HẬU CHO `{symbol}`**:\n"
            f"• ⭐ **Điểm số hội đồng**: `{score_val} / 10` | **Tỷ trọng đề xuất**: `{pos_val}% NAV`\n"
            f"• 🚦 **Tín hiệu**: {advice_badge}\n\n"
            f"{advice_body}\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"✨ *Bot by Nguyễn Hoàng Trịnh | TikTok: [@nguyenhoangtrinh4](https://www.tiktok.com/@nguyenhoangtrinh4) xin 1 follow ạ ❤️*\n"
            f"☕ *Ủng hộ admin: TPBank `10002654317` (NGUYEN HOANG TRINH)*"
        )
        await msg_wait.delete()
        try:
            await callback.message.answer(audit_text, parse_mode=ParseMode.MARKDOWN)
        except Exception:
            await callback.message.answer(audit_text)
    except Exception as e:
        logger.error(f"Lỗi khi trích xuất ma trận 10 AI cho {symbol}: {e}")
        await msg_wait.edit_text(f"❌ Có lỗi khi trích xuất dữ liệu: {str(e)}")

@dp.callback_query(F.data.startswith("full_"))
async def cb_full(callback: CallbackQuery):
    symbol = callback.data.split("_")[1]
    try:
        await callback.answer()
    except Exception:
        pass
    
    msg_wait = await callback.message.answer(f"⏳ Đang trích xuất báo cáo tác chiến chuyên sâu cho mã `{symbol}`...")
    try:
        loop = asyncio.get_event_loop()
        res = await loop.run_in_executor(None, fund.run_investment_committee, symbol)
        report_md = res["report_md"]

        await msg_wait.delete()
        try:
            if len(report_md) > 4000:
                await callback.message.answer(report_md[:4000], parse_mode=ParseMode.MARKDOWN)
                await callback.message.answer(report_md[4000:], parse_mode=ParseMode.MARKDOWN)
            else:
                await callback.message.answer(report_md, parse_mode=ParseMode.MARKDOWN)
        except Exception:
            await callback.message.answer(report_md)
    except Exception as e:
        logger.error(f"Lỗi khi tải báo cáo đầy đủ cho {symbol}: {e}")
        await msg_wait.edit_text(f"❌ Có lỗi khi tải báo cáo: {str(e)}")

@dp.callback_query(F.data.startswith("backtest_"))
async def cb_backtest(callback: CallbackQuery):
    symbol = callback.data.split("_")[1]
    try:
        await callback.answer()
    except Exception:
        pass
    await run_backtest_for_symbol(callback.message, symbol)

@dp.callback_query(F.data.startswith("risk_"))
async def cb_risk(callback: CallbackQuery):
    symbol = callback.data.split("_")[1]
    try:
        await callback.answer()
    except Exception:
        pass
    
    msg_wait = await callback.message.answer(f"⏳ Đang kiểm tra sổ sách tài chính & nguy cơ kẹt sàn mã `{symbol}`...")
    try:
        loop = asyncio.get_event_loop()
        company = await loop.run_in_executor(None, fund.fetcher.get_company_overview, symbol)
        fin = await loop.run_in_executor(None, fund.fetcher.get_financial_health, symbol)
        tech = await loop.run_in_executor(None, fund.fetcher.get_technical_analysis, symbol)
        burry = await loop.run_in_executor(None, fund.burry.analyze, company, fin)

        z_val = burry.get('altman_z_score', 0)
        try:
            z_float = float(z_val)
            if z_float >= 2.99:
                z_explain = "Cực kỳ lành mạnh, nguy cơ phá sản bằng 0"
            elif z_float >= 1.81:
                z_explain = "Vùng an toàn vừa phải, cần quan sát"
            else:
                z_explain = "NGUY HIỂM: Nợ quá nhiều, nguy cơ mất khả năng trả nợ!"
        except Exception:
            z_explain = "Đang theo dõi"

        text = (
            f"🛡️ **KIỂM TRA SỨC KHỎE TÀI CHÍNH & RỦI RO: `{symbol}`**\n"
            f"🏢 **{company.get('company_name', symbol)}**\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"🕵️ **Thám tử Michael Burry kết luận**: {burry.get('safety_status', 'N/A')}\n"
            f"• **Chỉ số an toàn nợ (Altman Z)**: `{burry.get('altman_z_score', 'N/A')}`\n"
            f"   └ *Giải thích: {z_explain}*\n"
            f"• **Tiền mặt thực tế thu về (CFO)**: `{fin.get('cfo_history', 'N/A')} tỷ VNĐ`\n"
            f"   └ *Xu hướng: {burry.get('cfo_trend', 'N/A')} (Nếu âm liên tục là bán hàng không thu được tiền thật)*\n"
            f"• **Tỷ lệ nợ vay trên vốn**: `{fin.get('debt_to_equity', 'N/A')}x` (Dưới 1.0x là an toàn)\n"
            f"• **Ý kiến công ty kiểm toán**: `{fin.get('audit_opinion', 'Chấp nhận toàn phần')}`\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"⚠️ **Độ an toàn thanh khoản (Chống kẹt hàng T+2.5)**: `{tech.get('floor_lock_risk', 'N/A')}`\n"
            f"• Số phiên bị giảm sàn 60 ngày qua: `{tech.get('floor_days_in_60d', 0)}` phiên\n"
            f"• Giá trị giao dịch trung bình ngày: `{tech.get('avg_daily_turnover_billion', 'N/A')} tỷ VNĐ/phiên`\n"
            f"• Mức rung lắc biến động ngày (ATR): `{tech.get('atr_14_vnd', 0):,.0f} VNĐ`\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"💡 **Lời khuyên cho bạn**: Chỉ nên đầu tư vào những doanh nghiệp có tiền mặt về túi thật (CFO dương) và thanh khoản dồi dào để luôn chủ động rút vốn an toàn khi cần!\n\n"
            f"✨ *Bot by Nguyễn Hoàng Trịnh | TikTok: [@nguyenhoangtrinh4](https://www.tiktok.com/@nguyenhoangtrinh4)*\n"
            f"☕ *Ủng hộ admin: TPBank `10002654317` (NGUYEN HOANG TRINH)*"
        )
        await msg_wait.delete()
        try:
            await callback.message.answer(text, parse_mode=ParseMode.MARKDOWN)
        except Exception:
            await callback.message.answer(text)
    except Exception as e:
        logger.error(f"Lỗi soi rủi ro cho {symbol}: {e}")
        await msg_wait.edit_text(f"❌ Có lỗi khi soi rủi ro: {str(e)}")

async def run_backtest_for_symbol(message: Message, symbol: str):
    wait_msg = await message.answer(f"⏳ **Đang mô phỏng giao dịch 5 năm quá khứ trên mã `{symbol}`**...\n*(Xem nếu mua bán theo kỷ luật của Bot trong 5 năm qua thì lời lỗ thế nào)*", parse_mode=ParseMode.MARKDOWN)
    
    try:
        loop = asyncio.get_event_loop()
        res = await loop.run_in_executor(None, backtester.run_backtest, symbol, 5)

        ret_val = res.get('total_return_pct', 0)
        ret_badge = "🟢 LÃI RỰC RỠ" if ret_val > 15 else ("🟢 CÓ LÃI" if ret_val > 0 else "🔴 THUA LỖ")
        bh_val = res.get('buy_and_hold_pct', 0)
        alpha_val = res.get('alpha_pct', 0)
        alpha_badge = f"+{alpha_val}% so với Ôm Lì (Buy & Hold)" if alpha_val > 0 else f"{alpha_val}%"
        max_win = res.get('max_win_pct', 0)
        max_loss = res.get('max_loss_pct', 0)

        text = (
            f"📊 **KẾT QUẢ MÔ PHỎNG 5 NĂM LỊCH SỬ: `{symbol}`**\n"
            f"*(Chiến lược: Cắt lỗ cứng -7%, Gồng lãi theo Trend MA50 & Trailing Stop, tuân thủ T+2.5)*\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"💰 **Vốn ban đầu**: `{res['initial_capital']:,.0f} VNĐ`\n"
            f"💵 **Vốn sau 5 năm**: `{res['final_capital']:,.0f} VNĐ`\n"
            f"📈 **Tăng trưởng tài khoản**: **`{ret_val:+.2f}%`** ({ret_badge})\n"
            f"⚡ **Hiệu quả vượt trội**: **`{alpha_badge}`**\n"
            f"   └ *(Nếu ôm lì Buy & Hold chỉ đạt {bh_val:+.2f}%, dính trọn các cú sập thị trường 2022)*\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"🎯 **Tỷ lệ lệnh thắng (Win Rate)**: **`{res['win_rate_pct']}%`** ({res['total_trades']} lệnh/5 năm)\n"
            f"⚖️ **Hệ số lãi / lỗ (Profit Factor)**: **`{res['profit_factor']}x`**\n"
            f"   └ *(Cứ mỗi 1 đồng thua lỗ thì kiếm lại được {res['profit_factor']} đồng tiền lãi!)*\n"
            f"🚀 **Lệnh thắng lớn nhất**: `+{max_win}%` (Nhờ gồng lãi trọn sóng)\n"
            f"🛡️ **Lệnh thua lớn nhất**: `{max_loss}%` (Được chốt chặn -7% bảo vệ tuyệt đối)\n"
            f"📉 **Sụt giảm vốn lớn nhất (MDD)**: **`{res['max_drawdown_pct']}%`** (Cực kỳ an toàn)\n"
            f"⏱️ **Thời gian giữ trung bình**: `{res['avg_holding_days']} phiên`\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"💡 **Bài học thực chiến cho người mới**:\n"
            f"• **Tại sao lợi nhuận bản cũ thấp?** Vì bản cũ bán non ở +15% và để 80% vốn chết. Bản mới đã kích hoạt **Trailing Stop gồng trọn sóng lớn (+25% đến +35%)** và phân bổ vốn tối ưu!\n"
            f"• **Bí quyết chiến thắng**: Trong đợt sập lịch sử 2022 (thị trường rơi -33%), Bot rút về tiền mặt đứng ngoài bảo toàn vốn, sau đó bắt trọn các sóng tăng 2023 - 2024 để tạo ra mức sinh lời vượt trội!\n\n"
            f"✨ *Bot by Nguyễn Hoàng Trịnh | TikTok: [@nguyenhoangtrinh4](https://www.tiktok.com/@nguyenhoangtrinh4)*\n"
            f"☕ *Ủng hộ admin: TPBank `10002654317` (NGUYEN HOANG TRINH)*"
        )
        await wait_msg.delete()
        try:
            await message.answer(text, parse_mode=ParseMode.MARKDOWN)
        except Exception:
            await message.answer(text)
    except Exception as e:
        await wait_msg.edit_text(f"❌ Lỗi khi chạy backtest: {str(e)}")

async def main():
    logger.info("Khởi động Bot Telegram Vietnam AI Hedge Fund (@trolychungandtrinh_bot)...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
